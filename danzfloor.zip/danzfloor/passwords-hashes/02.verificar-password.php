<?php
/*
¿Cómo verificamos un password?
Los passwords se almacenan para que se puedan utilizar como mecanismo de autenticación.
Ahora, si el password se hashea con un algoritmo irreversible, y si cada vez que ejecutamos la función
password_hash genera un hash diferente incluso para el mismo valor, ¿Cómo podemos comparar un password
contra ese hash?
Esa comparación la necesitamos poder para autenticar a un usuario.

Para realizar esa verificación, php nos ofrece una función que lo hace por nosotros, llamada:
password_verify.
*/
$password = "asdasd";
$hash = '$2y$10$JwCHVhqz0K3YymFx1glJ4euLa.QkAGwajOu/P64dUapPENoIl.gIW';

if(password_verify($password, $hash)) {
    echo "El password coincide con su hash :D";
} else {
    echo "Error. El password es incorrecto.";
}
