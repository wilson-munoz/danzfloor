<?php

$password = "123";

// Creamos el hash usando la función password_hash.
$hash = password_hash($password, PASSWORD_DEFAULT);

echo "La encriptación del password '" . $password . "' generó el hash: " . $hash;
