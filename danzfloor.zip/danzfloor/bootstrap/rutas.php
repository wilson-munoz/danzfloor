<?php

/**
 * @return string[][]
 */

function getRutas(): array {
    return [
        'home' => [
            'title' => 'Home',
        ],
        'data' => [
            'title' => 'Data',
        ],
        'data-detalle' => [
            'title' => 'Data detalle',
        ],
        'pec' => [
            'title' => 'Pec',
        ],
        'pec-detalle' => [
            'title' => 'Pec Detalle',
        ],
        'musica' => [
            'title' => 'Música',
        ],
        'foro-online' => [
            'title' => 'Foro Online',
        ],
        'networking' => [
            'title' => 'Networking',
        ],
        'que-es-danzfloor' => [
            'title' => '¿Que es Danzfloor?',
        ],
        'como-podes-involucrarte' => [
            'title' => '¿Como podés involucrarte?',
        ],
        'eventos-recomendados' => [
            'title' => 'Eventos Recomendados'
        ],
        'cronicas-dz' => [
            'title' => 'Cronicas dz'
        ],
        '404' => [
            'title' => 'Página no encontrada'
        ],
    ];
}



function getRutasAdmin(): array {
    return [
        'login' => [
            'title' => 'Iniciar Sesión',
        ],
        'home' => [
            'title' => 'Home'
        ],
        'data' => [
            'title' => 'Data',
        ],
        'data-nuevo' => [
            'title' => 'Data nuevo',
        ],
        'data-editar' => [
            'title' => 'Data editar',
        ],
        'pec' => [
            'title' => 'Pec',
        ],
        'pec-videos-nuevo' => [
            'title' => 'Agregar nuevo video',
        ],
        'pec-editorial-nuevo' => [
            'title' => 'Agregar un editorial nuevo'
        ],
        'pec-editorial-editar' => [
            'title' => 'Pec editorial editar'
        ],
        'pec-descarga-editar' => [
            'title' => 'Pec editorial editar'
        ],
        'musica' => [
            'title' => 'Música',
        ],
        'musica-premiere-nuevo' => [
            'title' => 'Premieres'
        ],
        'musica-videos-nuevo' => [
            'title' => 'Música',
        ],
        '404' => [
            'title' => 'Página no encontrada',
        ],
    ];
}