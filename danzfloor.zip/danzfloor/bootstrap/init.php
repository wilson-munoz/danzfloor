<?php
/*
 |--------------------------------------------------------------------------
 | Archivo de inicialización
 |--------------------------------------------------------------------------
 */

/*
 |--------------------------------------------------------------------------
 | Sesiones
 |--------------------------------------------------------------------------
 */
// Inicializamos el uso de sesiones con la función session_start() de php.


session_start();

/*
 |--------------------------------------------------------------------------
 | Constantes
 |--------------------------------------------------------------------------
 */
// La constante DIRECTORY_SEPARATOR retorna el caracter que sirva como separador de niveles de
// directorios en el sistema operativo.
const RUTA_RAIZ = __DIR__ . DIRECTORY_SEPARATOR . "..";

const RUTA_IMGS = RUTA_RAIZ . DIRECTORY_SEPARATOR . 'imgs';
