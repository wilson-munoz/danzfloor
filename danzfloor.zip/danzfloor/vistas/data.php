<?php
$datadz = (new Datadz)->todoDatadz();
?>

<?php
$mes = array("enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto", "septiembre", "octubre", "noviembre", "diciembre");
date_default_timezone_set('America/Argentina/Buenos_Aires');
?>

<main class="main">
    <section class="banner-data">
        <img src="./imgs/banner-data.jpg" alt="">
        <div>
            <h2>Data</h2>
            <img src="./imgs/icon-data.png" alt="">
        </div>
    </section>
    <section class="data-texto">
        <div class="data-head">
            <p>Siempre <span>está pasando algo nuevo en la escena.</span></p>
            <p>¡Enterate de todas las novedades y actualizate!</p>
        </div>
    </section>
    <section class="buscador">
        <form action="#">
            <div id="buscador">
                <label for="search">Buscar</label>
                <input type="text" id="search" name="buscador" placeholder="¿Que te gustaría saber hoy?">
                <button type="submit">  <i class="fas fa-search"></i> </button>
            </div>
        </form>
    </section>
    <section class="tags">
        <ul>
            <li><a href="">Artistas</a></li>
            <li><a href="">Proyectos</a></li>
            <li><a href="">Eventos</a></li>
            <li><a href="">Danzers</a></li>
        </ul>
    </section>
    <section id="data-article">

        <div class="data-article">
            <?php
            foreach ($datadz as $dat):
            ?>
            <a href="index.php?s=data-detalle&id=<?= $dat->getIdDatadz();?>">
                <article>
                    <img src="<?= 'imgs/' . $dat->getImagen(); ?>" alt="<?= $dat->getAltImagen() ?>">

                    <div>
                        <p style="font-size: .8em" class="fecha"> <?php echo "<strong>" . date("d") . " de " . $mes[date("m")-1] . "</strong>" . ", " . date("Y");  ?></p>
                        <h2><?= $dat->getTitulo(); ?>: <span><?= $dat->getSubtitulo(); ?></span></h2>
                        <p><?= $dat->getTextIntro(); ?></p>
                    </div>
                </article>
            </a>
            <?php
            endforeach;
            ?>
        </div>

        <div class="data-ver-mas">
            <a class="link-button" href="#">Ver Más</a>
        </div>
    </section>
</main>
