<?php
$id = (int) $_GET['id'];
$datadz = (new Datadz)->traerPorPkDatadz($id);

if(!$datadz) {
    header('Location: index.php?s=404');
    exit;
}
?>

<main class="main">
    <secrtion id="data-detalle">
        <h2><?= $datadz->getTituloDetalle() ?></h2>
        <div class="data-detalle-head">
            <p>#Talento emergente</p>
            <p>Escribe:</p>
        </div>

        <article class="data-detalle-text">
            <img src="<?= 'imgs/' . $datadz->getImagenDetalle(); ?>" alt="">
            <p><?= $datadz->getTextDetalle(); ?></p>
        </article>

    </secrtion>
</main>
