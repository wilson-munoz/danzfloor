<?php
$pec = (new Pec)->todoPec();

$pecvideos = (new PecVideos)->todoPecVideos();

$pecdescarga = (new PecDescarga)->todoPecDescarga();
?>

<?php
$mes = array("enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto", "septiembre", "octubre", "noviembre", "diciembre");
date_default_timezone_set('America/Argentina/Buenos_Aires');
?>

<main class="main">

    <section class="pec-banner">
        <img src="./imgs/pec-banner.jpg" alt="">
        <div>
            <h2>#Pec</h2>
            <p>Por una escena consciente</p>
        </div>
    </section>

    <section class="pec-texto">
        <p><span>#PorUnaEscenaConsciente</span> es una campaña que visibiliza las problemáticas que tiene la industria de la música electrónica en Argentina y en el mundo, tales como: <span>cuidado y contaminación auditiva, abusos y violencia en fiestas, perspectiva de género, salud mental, sostenibilidad, entre otras.</span></p>

        <p>Mediante contenido educativo y espacios de reflexión, <span>#PEC</span> busca prevenir daños y plantear de forma colectiva nuevos valores para las actuales y futuras generaciones de artistas, emprendedorxs y clubbers.</p>
    </section>

    <seccion class="pec-videos">
        <h2>Documentales</h2>
        <div>
            <?php
            foreach ($pecvideos as $pecvideo):
                ?>
                <div>
                    <iframe src="https://www.youtube.com/<?= $pecvideo->getLinkVideos(); ?>" " title="YouTube video player"  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                </div>
            <?php
            endforeach;
            ?>
        </div>
    </seccion>
    <section class="pec-editorial">
        <p>Guía de cuidado auditivo:  <a href="">Descargar</a></p>
        <h2>Editorial #Pec</h2>
    </section>

    <section class="buscador">
        <form action="#">
            <div id="buscador">
                <label for="search">Buscar</label>
                <input type="text" id="search" name="buscador" placeholder="¿Que te gustaría saber hoy?">
                <button type="submit">  <i class="fas fa-search"></i> </button>
            </div>
        </form>
    </section>
    <section class="tags tags-pec" >
        <ul>
            <li><a href="">Danzers</a></li>
            <li><a href="">Proyectos</a></li>
            <li><a href="">Artistas</a></li>
            <li><a href="">#Pec</a></li>
            <li><a href="">Eventos recomendados</a></li>
        </ul>
    </section>
    <section id="pec-noticias">
        <div class="pec-noticias">
            <?php
            foreach ($pec as $pe):
                ?>
                <a href="index.php?s=pec-detalle&id=<?= $pe->getIdPec(); ?>">
                    <article>
                        <img src="imgs/<?= $pe->getImagen(); ?>" alt="">
                        <div>
                            <p style="font-size: .8em" class="fecha"> <?php echo "<strong>" . date("d") . " de " . $mes[date("m")-1] . "</strong>" . ", " . date("Y");  ?></p>

                            <h2><?= $pe->getTitulo(); ?></h2>
                            <p><?= $pe->getTextIntro(); ?></p>
                        </div>
                    </article>
                </a>
            <?php
            endforeach;
            ?>
        </div>

        <div class="data-ver-mas">
            <a class="link-button" href="#">Ver Más</a>
        </div>
    </section>
    <section class="pec-descargar">
        <h2>Archivo completo #Pec</h2>
        <?php
        foreach ($pecdescarga as $pecdescargar ):
            ?>
            <div>
                <p><?= $pecdescargar->getTexto(); ?></p>
                <div class="data-ver-mas">
                    <a class="link-button" href="imgs/<?= $pecdescargar->getArchivo(); ?>" download="imgs/<?= $pecdescargar->getArchivo(); ?>">Descargar</a>
                </div>
            </div>
        <?php
        endforeach;
        ?>
    </section>
</main>
