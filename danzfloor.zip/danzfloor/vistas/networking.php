<main class="main">
    <section class="networking">
        <h2><span>Net</span>working DZ</h2>
        <article class="networking-head">
            <div>
                <h3>Introducción</h3>
                <p>Nuevos vínculos para conectarnos con potencia.</p>

                <p> Danzfloor Networking es un encuentro especialmente organizado para artistas, productorxs de eventos y emprendedorxs que buscan tejer redes, capacitarse y adquirir nuevas herramientas para desarrollarse dentro de la industria.</p>

                <p>El escenario de este evento invita a reflexionar, moviliza y da lugar a que cada unx pueda contar su experiencia personal y aprender escuchando la de otrxs.</p>
            </div>
            <div>
                <img src="./imgs/networking-img.jpg" alt="">
            </div>
        </article>
        <div class="networking-flecha">
            <img src="./imgs/flecha.png" alt="">
        </div>
        <div class="te-gustaria">
            <h2><span>¿Te gustaría</span> <span> ser parte de futuras</span> <span>ediciones?</span> </h2>
        </div>

        <div class="networking-form">
            <p>COMPLETÁ LOS SIGUIENTES DATOS:</p>
            <form action="#">
                <div>
                    <label for="nombre" hidden >Nombre</label>
                    <input type="text" id="nombre" name="nombre" placeholder="Nombre">
                </div>
                <div>
                    <label for="email" hidden>Mail</label>
                    <input type="email" id="email" name="email" placeholder="Mail">
                </div>
                <div>
                    <label for="rol" hidden>Rol</label>
                    <input type="text" id="rol" name="rol" placeholder="Rol: ¿sos dj, productorx de eventos, fotógrafx, booker, etc...?">
                </div>
                <div>
                    <textarea name="mensaje" placeholder="¿Por qué te interesa participar?"></textarea>
                </div>
                <input type="submit" value="Enviar">
            </form>
        </div>
    </section>
    <section class="banner-networking">
        <img src="./imgs/banner-networking.jpg" alt="">
        <div>
            <h2>Crónica DZ</h2>
            <p>¿Qué sucedió en los encuentros anteriores?</p>
            <a href="">Leé</a>
        </div>
    </section>
</main>