<main class="main">
    <!-- BANNER -->
    <section class="banner" id="home">
        <div class="callbacks_container">
            <ul class="rslides" id="slider3">
                <li>
                    <div class="slider-info bg1 w3-agile-grid">
                        <div class="bs-slider-overlay">
                        </div>
                    </div>
                </li>
                <li>
                    <div class="slider-info bg2 w3-agile-grid">
                        <div class="bs-slider-overlay">
                        </div>
                    </div>
                </li>
                <li>
                    <div class="slider-info bg3 w3-agile-grid">
                        <div class="bs-slider-overlay">
                        </div>
                    </div>
                </li>
            </ul>
        </div>
    </section>
    <!--FIN BANNER-->

    <section class="borde__separador-right">
        <div></div>
        <div>
            <span></span>
            <span></span>
        </div>
    </section>


    <section class="home-section">
        <a class="home-link" href="index.php?s=data">
            <figure>
                <picture>
                    <source media="(max-width: 480px)" srcset="imgs/home-c.jpg">
                    <source media="(max-width: 600px)" srcset="imgs/home-t.jpg">
                    <img src="imgs/img1-home.jpg" alt="Djs">
                </picture>
    <!--                <img src="imgs/banner-lee-home.jpg" alt="">-->
                    <div class="home-text">
                        <h2>Leé</h2>
                        <p>La data</p>
                        <ul>
                            <li>#Newz</li>
                            <li>#Notasdz</li>
                            <li>#Pec</li>
                        </ul>
                    </div>
                    <div class="capa"></div>
            </figure>
        </a>
        <!--        Separador left-->
        <div class="borde__separador-left">
            <div>
                <span></span>
                <span></span>
            </div>
            <div>
            </div>
        </div>
        <a class="home-link" href="index.php?s=musica">
            <figure>
                <picture>
                    <source media="(max-width: 480px)" srcset="imgs/escucha-c.jpg">
                    <source media="(max-width: 600px)" srcset="imgs/escucha-t.jpg">
                    <img src="imgs/escucha.jpg" alt="Djs">
                </picture>
                <div class="home-text">
                    <h2>Escuchá</h2>
                    <p>Nuevos djs y productorxs emergentes</p>
                    <ul>
                        <li>#Premieres</li>
                        <li>#Podcasts</li>
                    </ul>
                </div>
                <div class="capa"></div>
            </figure>
        </a>
<!--        Separador right-->
        <div class="borde__separador-right">
            <div></div>
            <div>
                <span></span>
                <span></span>
            </div>
        </div>
        <a class="home-link" href="index.php?s=musica#musica-videos">
            <figure>
                <picture>
                    <source media="(max-width: 480px)" srcset="imgs/mira-c.jpg">
                    <source media="(max-width: 600px)" srcset="imgs/mira-t.jpg">
                    <img src="imgs/mira.jpg" alt="Djs">
                </picture>
<!--                <img src="imgs/rectangle-103.jpg" alt="">-->
                <div class="home-text">
                    <h2>Mirá</h2>
                    <p>Streamings y cursos de producción musical</p>
                    <ul>
                        <li>#Dztv</li>
                        <li>#Vzuals</li>
                        <li>#Masterclasses</li>
                    </ul>
                </div>
                <div class="capa">
                </div>
            </figure>
        </a>
    </section>
    <!--        fin items home-->
    <section class="eventos-home">
            <div class="eventos__home-title">
                <h2><span>Eventos</span> <span>Recomendados</span> </h2>
                <a class="link-button link-recomendados" href="index.php?s=eventos-recomendados">Ver todos</a>
            </div>
            <div class="eventos__home-img">
                <img src="imgs/pexels-maor-attias.jpg" alt="">
                <a class="link-button" href="index.php?s=eventos-recomendados">Ver todos</a>
            </div>
    </section>
<!--    <span class="borde_circicle"></span>-->
    <section class="borde__que-dz">
        <span>
                <div class="borde_circicle"></div>
        </span>
        <span></span>
<!--        <span></span>-->
    </section>

    <section id="que-es-dz">
        <div class="que-es-dz">
            <div class="que-es-dz-title">
                <h2><span>¿Que es</span> <span>Danzfloor?</span></h2>
                <img src="imgs/que-es-dz-img.jpg" alt="">
            </div>
            <div class="que-es-dz-bottom">
                <h2><span>¿Que es</span> <span>Danzfloor?</span></h2>
                <div>
                    <img src="imgs/flecha.png" alt="">
                    <a class="link-button botton-home" href="index.php?s=que-es-danzfloor">Conocé +</a>
                </div>
            </div>
        </div>
    </section>
    <section class="gracias-home">
        <img src="imgs/gracias-home.png" alt="">
    </section>

    <section>
        <!------------Design By Pradeep Singh Tomar----------->

        <div class="container">
            <p style="color: #17a2b8">Desarrollo pendiente de slide para escritorio </p>
            <section id="testim" class="testim">
                <div class="testim-cover">
                    <div class="wrap">

                        <span id="right-arrow" class="arrow right fa fa-chevron-right" style="display: none"></span>
                        <span id="left-arrow" class="arrow left fa fa-chevron-left " style="display: none"></span>
                        <ul id="testim-dots" class="dots">
                            <li class="dot active"></li><!--
                    --><li class="dot"></li><!--
                    --><li class="dot"></li><!--
                    --><li class="dot"></li><!--
                    --><li class="dot"></li>
                        </ul>
                        <div id="testim-content" class="cont">

                            <div class="active">
                                <h2>@lawgustine</h2>
                                <p>Increíble encuentro, energí, sinergia e intercambio. Agradecemos la invitación una verdadera oportunidad de conocer la escena desde adentro y así poder aportar herramientas legales con miradara y abordaje empáticos. Quiero destacar enfáticamente las técnicas de conexión en el encuentro, que me parecieron fantásticas! Gracias equipo Danzfloor!</p>
                            </div>

                            <div>
                                <h2>@christianemaestre</h2>
                                <p>Gracias por tanto!</p>
                            </div>

                            <div>
                                <h2>@soyequelcanle</h2>
                               <p>Formar parte de espacios así es enriquecedor y admirable por todo el trabajo que hacen. Gracias Danzfloor!</p>
                            </div>

                            <div>
                                <h2>@yopyesiis</h2>
                                <p>Agradecida por permitirme formar parte de esto tan groso. Gracias por llevarlo adelante, se necesita bocha y entre todes podemos hacer una escena consciente.</p>
                            </div>

                            <div>
                                <h2>@erikahalliday</h2>
                                <p>Gracias por darme siempre un espacio! Aguante @danzfloorapp</p>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </section>

    <section class="forma-parte">
        <h2>¡Formá parte!</h2>
        <p>¿Te gustaria contribuir activamente con DZ?</p>
        <a class="link-button" href="index.php?s=como-podes-involucrarte" target="_blank">Colaborá</a>
    </section>
</main>