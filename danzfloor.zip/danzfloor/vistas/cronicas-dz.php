<?php
$cronicasdz = (new Cronicasdz)->todoCronicasdz();
?>
<main class="mal">
    <section>
        <h2>Cronicas Dz</h2>

        <img src="../imgs/cronicasdz.jpg" alt="">

    </section>
</main>
