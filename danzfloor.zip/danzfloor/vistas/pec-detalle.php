<?php
$id = (int) $_GET['id'];
$pec = (new Pec)->traerPorPkPec($id);

if(!$pec) {
    header('Location: index.php?s=404');
    exit;
}
?>

<main class="main">
    <secrtion class="pec-detalle">
        <h1><?= $pec->getTituloDetalle(); ?></h1>
        <div class="data-detalle-head">
            <p>#Talento emergente</p>
            <p>Escribe:</p>
        </div>

        <article class="data-detalle-text">
            <img src="<?= 'imgs/' . $pec->getImagenDetalle(); ?>" alt="">
            <p><?= $pec->getTextDetalle(); ?></p>
        </article>

    </secrtion>
</main>
