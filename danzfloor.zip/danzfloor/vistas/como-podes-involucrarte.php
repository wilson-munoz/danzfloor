<main class="main">
    <section class="como-podes-involucrarte">
        <div class="involucrarte-head">
            <h2><span>¿Como podés</span> <span>involucrarte?</span></h2>
            <p>Con tu aporte nos ayudas a evolucionar</p>
        </div>
        <div class="mercado-pago">
            <img src="./imgs/bk-mercadopago.jpg" alt="">
            <div>
                <h3>Danzfloor es un proyecto autogestivo</h3>

                <p>Detrás, hay un  <span>grupo humano que hace con mucha pasión.</span></p>

                <p>Si nuestro hacer te resuena y <span>valorás este espacio,</span> <span class="ayudanos">¡Ayudanos a seguir creando!</span> </p>

                <div class="mercado-pago-link">
                    <a href="https://www.mercadopago.com.ar" target="_blank">Link de pago</a>
                    <img src="./imgs/logo-mercadopago.png" alt="">
                </div>
            </div>
        </div>
    </section>
    <section class="contacto-involucrarte">
        <h2>¡Forma parte de nuestro equipo de colaboradorxs!</h2>
        <p>Si tenes alma de comunicadorx y te interesa redactar notas sobre cultura electrónica hispanohablante o si sos parte de algún proyecto con el que podamos hacer sinergia.
             <span>¡Escribinos!</span></p>

        <div class="form-involucrarte">
            <form action="#">
                <div>
                    <label for="nombre">Nombre</label>
                    <input type="text" id="nombre" name="nombre" placeholder="Nombre">
                </div>
                <div>
                    <label for="email">Email</label>
                    <input type="text" id="email" name="email" placeholder="Mail">
                </div>
                <div>
                    <label for="mensaje">Mensaje</label>
                    <textarea name="mensaje" id="mensaje"  placeholder="Mensaje"></textarea>
                </div>
                <div class="button">
                    <button type="submit">Enviar</button>
                </div>
            </form>
        </div>
    </section>
</main>