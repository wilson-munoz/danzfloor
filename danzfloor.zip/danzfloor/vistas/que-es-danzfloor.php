<main class="main">
    <section class="sobre-danzfloor">
<!--        <h2>Manifiesto</h2>-->
        <img src="imgs/manifiesto.png" alt="">

        <p>La música electrónica siempre fue el motivo para encontrarnos.</p>

        <p>Hace más de 40 años, Somos pura energía creativa, Un movimiento histórico que evoluciona en comunidad, Que marcha por la locura de ser libres. </p>

        <p>Por más que la búsqueda de cada unx, Sea personal y diferente, Lo único que queremos es expresarnos, aunque a veces no sepamos qué, ni cómo hacerlo.</p>

        <p>Artistas, productores y amantes de la cultura electrónica, Este espacio es para nosotrxs, donde podemos mirarnos a los ojos y preguntarnos:</p>

        <p>“¿Qué es lo que nos hace falta para seguir bailándonos la vida?”</p>
        <div class="logo-dos">
            <img src="./imgs/logo-dos.png" alt="" >
        </div>
    </section>
    <section class="que-es-dz-section">
        <div>
            <h2>¿Qué es Danzfloor?</h2>
            <p>DZ es una comunidad de artistas, productorxs y amantes de la cultura electrónica.</p>

            <p>Se fundó en Argentina en 2019 como guía de eventos y terminó convirtiéndose en una de las plataformas de contenido ONLINE y OFFLINE más completas sobre la escena del país, con especial enfoque en visibilizar las artes electrónicas emergentes.</p>

            <p>Principales valores de Danzfloor: Conectar No solo a la comunidad, sino también a las personas consigo mismas y su propósito artístico.</p>

            <p>Potenciar Difundiendo el trabajo de pequeñxs emprendedores y artistas que desean insertarse en la escena.</p>

            <p>Transformar Escuchando e investigando sobre las necesidades para aportar herramientas educativas mediante #PEC.</p>

            <p>Culturizar Resaltando diariamente el desarrollo de la industria hispanohablante, a través de contenido de valor.</p>
        </div>
        <div>
            <img src="./imgs/dz-img.jpg" alt="">
        </div>
    </section>
    <section class="equipo">
        <ul>
            <li><img src="./imgs/1.jpg" alt=""></li>
            <li><img src="./imgs/2.jpg" alt=""></li>
            <li><img src="./imgs/3.jpg" alt=""></li>
            <li><img src="./imgs/4.jpg" alt=""></li>
        </ul>
    </section>
    <section class="saber-mas">
        <div>
            <h2>¿Querés <span>saber más?</span></h2>
            <p><span>Contactá a nuestro</span> <span>equipo de creadores</span></p>
        </div>
        <img src="./imgs/flecha-abajo.png" alt="">
    </section>
</main>




















