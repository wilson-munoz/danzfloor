<?php

$musicapremieres = (new Musicapremieres)->todoMusicapremieres();

$musicavideos = (new MusicaVideos)->todoMusicaVideos();


?>
<main class="main">
    <section class="banner-musica">
        <img src="./imgs/banner-musica.jpg" alt="">
        <div>
            <h2>Música</h2>
            <p>Escuchá podcasts y premieres de DJs y Productorxs emergentes.</p>
            <p>Descubrí nuevos talentos.</p>
        </div>
    </section>
    <section class="musica-audios">
        <h2>Premieres</h2>
        <div>
            <?php
            foreach ($musicapremieres as $musicapremiere):
                ?>
                <iframe width="100%" height="" scrolling="no" frameborder="no" allow="autoplay" src="https://w.soundcloud.com/player/?url=https%3A//api.soundcloud.com/<?= $musicapremiere->getLink(); ?>  "></iframe>

                <div style="font-size: 10px; color: #cccccc;line-break: anywhere;word-break: normal;overflow: hidden;white-space: nowrap;text-overflow: ellipsis; font-family: Interstate,Lucida Grande,Lucida Sans Unicode,Lucida Sans,Garuda,Verdana,Tahoma,sans-serif;font-weight: 100;"></div>
            <?php
            endforeach;
            ?>
        </div>
    </section>
    <section class="musica-videos" id="musica-videos">
        <h2>Mirá</h2>
        <div id="musica-videos">
            <?php
            foreach ($musicavideos as $musicavideo):
                ?>
                <div>
                    <iframe src="https://www.youtube.com/<?= $musicavideo->getLink(); ?>" " title="YouTube video player"  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                </div>
            <?php
            endforeach;
            ?>
        </div>
    </section>

</main>