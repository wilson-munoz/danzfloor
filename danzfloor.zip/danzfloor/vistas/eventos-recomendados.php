<?php
$eventosrecomendados = (new EventosRecomendados)->todoEventosRecomendados();
?>
<?php
$mes = array("enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto", "septiembre", "octubre", "noviembre", "diciembre");
date_default_timezone_set('America/Argentina/Buenos_Aires');
?>

<main class="main">
    <section class="eventos-recomendados">
        <h2><span>Eventos</span> <span>recomendados</span></h2>
        <img src="./imgs/eventos-recomendados.jpg" alt="">
    </section>
    <section class="buscador">
        <form action="#">
            <div id="buscador">
                <label for="search">Buscar</label>
                <input type="text" id="search" name="buscador" placeholder="¿Que te gustaría saber hoy?">
                <button type="submit">  <i class="fas fa-search"></i> </button>
            </div>
        </form>
    </section>
    <section class="tags">
        <ul>
            <li><a href="">Artistas</a></li>
            <li><a href="">Proyectos</a></li>
            <li><a href="">Eventos</a></li>
            <li><a href="">Danzers</a></li>
        </ul>
    </section>
    <section class="recomendados-articles">
        <?php
        foreach ($eventosrecomendados as $eventosrecomendado):
        ?>
        <article>
            <img src="<?= 'imgs/' . $eventosrecomendado->getImagen(); ?>" alt="">
            <div>
                <p style="font-size: .8em" class="fecha"> <?php echo "<strong>" . date("d") . " de " . $mes[date("m")-1] . "</strong>" . ", " . date("Y");  ?></p>
                <h2><?= $eventosrecomendado->getTitulo(); ?></h2>
                <p><?= $eventosrecomendado->getText(); ?></p>
            </div>
        </article>
        <?php
        endforeach;
        ?>

        <div class="data-ver-mas">
            <a class="link-button" href="#">Ver Más</a>
        </div>
    </section>
</main>