<?php

class Usuario
{
    protected $id_usuarios;
    protected $fk_roles;
    protected $email;
    protected $password;

    /**
     * @return mixed
     */
    public function getIdUsuarios()
    {
        return $this->id_usuarios;
    }

    /**
     * @param mixed $id_usuarios
     */
    public function setIdUsuarios($id_usuarios): void
    {
        $this->id_usuarios = $id_usuarios;
    }

    /**
     * @return mixed
     */
    public function getFkRoles()
    {
        return $this->fk_roles;
    }

    /**
     * @param mixed $fk_roles
     */
    public function setFkRoles($fk_roles): void
    {
        $this->fk_roles = $fk_roles;
    }

    /**
     * @return mixed
     */
    public function getEmail()
    {
        return $this->email;
    }

    /**
     * @param mixed $email
     */
    public function setEmail($email): void
    {
        $this->email = $email;
    }

    /**
     * @return mixed
     */
    public function getPassword()
    {
        return $this->password;
    }

    /**
     * @param mixed $password
     */
    public function setPassword($password): void
    {
        $this->password = $password;
    }

    public function traerPorEmail(string $email): ?Usuario
    {
        $db = (new Conexion())->getConexion();
        $query = "SELECT * FROM usuarios
                WHERE email = ?";
        $stmt = $db->prepare($query);
        $stmt->execute([$email]);

        $stmt->setFetchMode(PDO::FETCH_CLASS, self::class);
        $usuario = $stmt->fetch();

        if(!$usuario) {
            return null;
        }

        return $usuario;
    }



}