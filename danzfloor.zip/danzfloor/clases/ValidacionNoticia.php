<?php

class ValidacionNoticia
{
    /**
     * @var array - Los datos a validar.
     */
    protected $data = [];

    /**
     * @var array - Los errores ocurridos en la validación.
     */
    protected $errores = [];

    /**
     * @param array $data - Los datos a validar.
     */
    public function __construct(array $data)
    {
        $this->data = $data;
    }

    /**
     * Ejecuta las validaciones.
     */
    public function ejecutar()
    {
        if(empty($this->data['titulo'])) {
            $this->errores['titulo'] = "Tenés que escribir el título de la noticia";
        } else if(strlen($this->data['titulo']) < 5) { // strlen => string length
            $this->errores['titulo'] = "El título de la noticia debe tener al menos 10 caracteres";
        }

//        To do  fijarse si esto se valida
        if(empty($this->data['subtitulo'])) {
            $this->errores['subtitulo'] = "Escribí el subtitulo de la noticia (opcional)";
        } else if(strlen($this->data['subtitulo']) < 0) { // strlen => string length
            $this->errores['subtitulo'] = "El subtítulo de la noticia debe tener al menos 1 caracter";
        }


        if(empty($this->data['text_intro'])) {
            $this->errores['text_intro'] = "Tenés que escribir la intro de la noticia";
        } else if(strlen($this->data['text_intro']) < 3) { // strlen => string length
            $this->errores['text_intro'] = "La intro de la noticia debe tener al menos 3 caracteres";
        }


        if(empty($this->data['titulo_detalle'])) {
            $this->errores['titulo_detalle'] = "Tenés que escribir el titulo del detalle de la noticia";
        }else if(strlen($this->data['titulo_detalle']) < 3) { // strlen => string length
            $this->errores['titulo_detalle'] = "El titulo del detalle de la noticia debe tener al menos 3 caracteres";
        }


        if(empty($this->data['text_detalle'])) {
            $this->errores['text_detalle'] = "Tenés que escribir el texto del detalle de la noticia";
        } else if(strlen($this->data['text_intro']) < 3) { // strlen => string length
            $this->errores['text_detalle'] = "El texto del detalle de la noticia debe tener al menos 3 caracteres";
        }

        if(empty($this->data['alt_imagen'])) {
            $this->errores['alt_imagen'] = "Tenés que escribir la descripción de la imagen";
        }

//        if(empty($this->data['img_alt_imagen'])) {
//            $this->errores['img_alt_imagen'] = "Tenés que escribir la descripción de la imagen";
//        }
    }

    /**
     * Si ocurrieron errores en la validación.
     *
     * @return bool
     */
    public function hayErrores(): bool
    {
        return count($this->errores) > 0;
    }

    /**
     * @return array
     */
    public function getErrores(): array
    {
        return $this->errores;
    }
}
