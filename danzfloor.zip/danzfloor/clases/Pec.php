<?php

class Pec
{
    protected $id_pec;
    protected $imagen;
    protected $alt_imagen;
    protected $fecha;
    protected $titulo;
    protected $subtitulo;
    protected $text_intro;
    protected $titulo_detalle;
    protected $imagen_detalle;
    protected $img_alt_detalle;
    protected $text_detalle;

    /**
     * @return mixed
     */
    public function getTituloDetalle()
    {
        return $this->titulo_detalle;
    }

    /**
     * @param mixed $titulo_detalle
     */
    public function setTituloDetalle($titulo_detalle): void
    {
        $this->titulo_detalle = $titulo_detalle;
    }


    /**
     * @return mixed
     */
    public function getIdPec()
    {
        return $this->id_pec;
    }

    /**
     * @param mixed $id_pec
     */
    public function setIdPec($id_pec): void
    {
        $this->id_pec = $id_pec;
    }

    /**
     * @return mixed
     */
    public function getImagen()
    {
        return $this->imagen;
    }

    /**
     * @param mixed $imagen
     */
    public function setImagen($imagen): void
    {
        $this->imagen = $imagen;
    }

    /**
     * @return mixed
     */
    public function getAltImagen()
    {
        return $this->alt_imagen;
    }

    /**
     * @param mixed $alt_imagen
     */
    public function setAltImagen($alt_imagen): void
    {
        $this->alt_imagen = $alt_imagen;
    }

    /**
     * @return mixed
     */
    public function getFecha()
    {
        return $this->fecha;
    }

    /**
     * @param mixed $fecha
     */
    public function setFecha($fecha): void
    {
        $this->fecha = $fecha;
    }

    /**
     * @return mixed
     */
    public function getTitulo()
    {
        return $this->titulo;
    }

    /**
     * @param mixed $titulo
     */
    public function setTitulo($titulo): void
    {
        $this->titulo = $titulo;
    }

    /**
     * @return mixed
     */
    public function getSubtitulo()
    {
        return $this->subtitulo;
    }

    /**
     * @param mixed $subtitulo
     */
    public function setSubtitulo($subtitulo): void
    {
        $this->subtitulo = $subtitulo;
    }

    /**
     * @return mixed
     */
    public function getTextIntro()
    {
        return $this->text_intro;
    }

    /**
     * @param mixed $text_intro
     */
    public function setTextIntro($text_intro): void
    {
        $this->text_intro = $text_intro;
    }

    /**
     * @return mixed
     */
    public function getImagenDetalle()
    {
        return $this->imagen_detalle;
    }

    /**
     * @param mixed $imagen_detalle
     */
    public function setImagenDetalle($imagen_detalle): void
    {
        $this->imagen_detalle = $imagen_detalle;
    }

    /**
     * @return mixed
     */
    public function getImgAltDetalle()
    {
        return $this->img_alt_detalle;
    }

    /**
     * @param mixed $img_alt_detalle
     */
    public function setImgAltDetalle($img_alt_detalle): void
    {
        $this->img_alt_detalle = $img_alt_detalle;
    }

    /**
     * @return mixed
     */
    public function getTextDetalle()
    {
        return $this->text_detalle;
    }

    /**
     * @param mixed $text_detalle
     */
    public function setTextDetalle($text_detalle): void
    {
        $this->text_detalle = $text_detalle;
    }



    /**
     * Traemos los datos de data desde la base
     * @return Pec[]
     */
    public function todoPec(): array
    {
        $db = (new Conexion())->getConexion();
        $query = "SELECT * FROM pec";
        $stmt = $db->prepare($query);
        $stmt->execute();

        $stmt->setFetchMode(PDO::FETCH_CLASS, self::class);

        return $stmt->fetchAll();
    }

    public function traerPorPkPec(int $pk): ?Pec
    {
        $db = (new Conexion())->getConexion();
        $query = "SELECT * FROM pec 
                  WHERE id_pec = ?";
        $stmt = $db->prepare($query);

        $stmt->execute([$pk]);
        $stmt->setFetchMode(PDO::FETCH_CLASS, self::class);
        $pec = $stmt->fetch();

        if(!$pec) {
            return null;
        }
        return $pec;
    }


    /**
     * Crea un nuevo editorial en la base de datos.
     *
     * @param array $data
     * @throws PDOException
     */
    public function crearpec(array $data)
    {
        $db = (new Conexion())->getConexion();
        // NO OLVIDAR LOS HOLDERS.
        $query = "INSERT INTO pec (fk_usuarios, fecha, imagen, alt_imagen, titulo, text_intro, titulo_detalle, imagen_detalle, text_detalle)
                VALUES (:fk_usuarios, NOW(), :imagen, :alt_imagen, :titulo, :text_intro, :titulo_detalle, :imagen_detalle, :text_detalle)";
        $stmt = $db->prepare($query);
        $stmt->execute([
            'fk_usuarios'       => $data['fk_usuarios'],
            'imagen'            => $data['imagen'],
            'alt_imagen'        => $data['alt_imagen'],
            'titulo'            => $data['titulo'],
            'text_intro'        => $data['text_intro'],
            'titulo_detalle'    => $data['titulo_detalle'],
            'imagen_detalle'    => $data['imagen_detalle'],
            'text_detalle'      => $data['text_detalle']
        ]);
    }



//    public function editar(int $pk, array $data)
    public function editarpec(int $id, array $pec)
    {
        $db = (new Conexion())->getConexion();
        $query = "UPDATE pec
                  SET   fk_usuarios  = :fk_usuarios,
                        imagen       = :imagen,
                        alt_imagen   = :alt_imagen,
                        titulo       = :titulo,
                        text_intro = :text_intro,
                        titulo_detalle = :titulo_detalle,
                        text_detalle = :text_detalle,
                        imagen_detalle = :imagen_detalle,
                        img_alt_detalle = :img_alt_detalle
                  WHERE id_pec = :id_pec";

        $stmt = $db->prepare($query);
        $stmt->execute([
            'id_pec'            => $id,
            'fk_usuarios'       => $pec['fk_usuarios'],
            'imagen'            => $pec['imagen'],
            'alt_imagen'        => $pec['alt_imagen'],
            'titulo'            => $pec['titulo'],
            'text_intro'        => $pec['text_intro'],
            'titulo_detalle'    => $pec['titulo_detalle'],
            'text_detalle'      => $pec['text_detalle'],
            'imagen_detalle'    => $pec['imagen_detalle'],
            'img_alt_detalle'   => $pec['img_alt_detalle']
        ]);
    }


    /**
     * Elimina el item por su PK de la base de datos.
     *
     * @param int $pk
     */
    public function eliminarpec(int $pk)
    {
        $db = (new Conexion())->getConexion();
        $query = "DELETE FROM pec
                  WHERE id_pec= ?";
        $stmt = $db->prepare($query);
        $stmt->execute([$pk]);
    }



}