<?php
class MusicaVideos
{
    protected $id_musicavideos;
    protected $link;

    /**
     * @return mixed
     */
    public function getIdMusicavideos()
    {
        return $this->id_musicavideos;
    }

    /**
     * @param mixed $id_musicavideos
     */
    public function setIdMusicavideos($id_musicavideos): void
    {
        $this->id_musicavideos = $id_musicavideos;
    }

    /**
     * @return mixed
     */
    public function getLink()
    {
        return $this->link;
    }

    /**
     * @param mixed $link
     */
    public function setLink($link): void
    {
        $this->link = $link;
    }



    /**
     * Busca todos los videos de la base de datos.
     *
     * @return MusicaVideos[]
     */
    public function todoMusicaVideos(): array
    {
        $db = (new Conexion())->getConexion();
        $query = "SELECT * FROM musicavideos";
        $stmt = $db->prepare($query);
        $stmt->execute();

        $stmt->setFetchMode(PDO::FETCH_CLASS, self::class);
        return $stmt->fetchAll();
    }


    /**
     * Crea un item en la base de datos.
     *
     * @param array $data
     * @throws PDOException
     */
    public function crearmusicavideos(array $data)
    {
        $db = (new Conexion())->getConexion();
        $query = "INSERT INTO musicavideos (fk_usuarios,  link)
                VALUES ( :fk_usuarios, :link)";
        $stmt = $db->prepare($query);
        $stmt->execute([
            'fk_usuarios'       => $data['fk_usuarios'],
            'link'       => $data['link']
        ]);
    }


    /**
     * Elimina el item por su PK de la base de datos.
     *
     * @param int $pk
     */
    public function eliminarMusicaVideos(int $pk)
    {
        $db = (new Conexion())->getConexion();
        $query = "DELETE FROM musicavideos
                  WHERE id_musicavideos = ?";
        $stmt = $db->prepare($query);
        $stmt->execute([$pk]);
    }

}