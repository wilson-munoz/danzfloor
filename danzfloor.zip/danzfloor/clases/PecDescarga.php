<?php

class PecDescarga
{
    protected $id_pecdescarga;
    protected $texto;
    protected $archivo;

    /**
     * @return mixed
     */
    public function getIdPecdescarga()
    {
        return $this->id_pecdescarga;
    }

    /**
     * @param mixed $id_pecdescarga
     */
    public function setIdPecdescarga($id_pecdescarga): void
    {
        $this->id_pecdescarga = $id_pecdescarga;
    }

    /**
     * @return mixed
     */
    public function getTexto()
    {
        return $this->texto;
    }

    /**
     * @param mixed $texto
     */
    public function setTexto($texto): void
    {
        $this->texto = $texto;
    }

    /**
     * @return mixed
     */
    public function getArchivo()
    {
        return $this->archivo;
    }

    /**
     * @param mixed $archivo
     */
    public function setArchivo($archivo): void
    {
        $this->archivo = $archivo;
    }



    /**
     * Traemos los datos de data desde la base
     * @return Pec[]
     */
    public function todoPecDescarga(): array
    {
        $db = (new Conexion())->getConexion();
        $query = "SELECT * FROM pecdescarga";
        $stmt = $db->prepare($query);
        $stmt->execute();

        $stmt->setFetchMode(PDO::FETCH_CLASS, self::class);

        return $stmt->fetchAll();
    }

    public function traerPorPkPecDescarga(int $pk): ?PecDescarga
    {
        $db = (new Conexion())->getConexion();
        $query = "SELECT * FROM pecdescarga 
                  WHERE id_pecdescarga = ?";
        $stmt = $db->prepare($query);

        $stmt->execute([$pk]);
        $stmt->setFetchMode(PDO::FETCH_CLASS, self::class);
        $data = $stmt->fetch();

        if(!$data) {
            return null;
        }
        return $data;
    }



//    public function editar(int $pk, array $data)
    public function editarpecdescarga(int $id, array $data)
    {
        $db = (new Conexion())->getConexion();
        $query = "UPDATE pecdescarga
                  SET   fk_usuarios  = :fk_usuarios,
                        texto       = :texto,
                        archivo       = :archivo
                  WHERE id_pecdescarga = :id_pecdescarga";

        $stmt = $db->prepare($query);
        $stmt->execute([
            'id_pecdescarga'    => $id,
            'fk_usuarios'       => $data['fk_usuarios'],
            'texto'             => $data['texto'],
            'archivo'           => $data['archivo']
        ]);
    }




}