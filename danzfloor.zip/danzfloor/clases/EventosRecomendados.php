<?php

class EventosRecomendados {
    protected $id_eventosrecomendados;
    protected $imagen;
    protected $alt_imagen;
    protected $fecha;
    protected $titulo;
    protected $text;
    protected $tag;

    /**
     * @return mixed
     */
    public function getIdEventosrecomendados()
    {
        return $this->id_eventosrecomendados;
    }

    /**
     * @param mixed $id_eventosrecomendados
     */
    public function setIdEventosrecomendados($id_eventosrecomendados): void
    {
        $this->id_eventosrecomendados = $id_eventosrecomendados;
    }

    /**
     * @return mixed
     */
    public function getImagen()
    {
        return $this->imagen;
    }

    /**
     * @param mixed $imagen
     */
    public function setImagen($imagen): void
    {
        $this->imagen = $imagen;
    }

    /**
     * @return mixed
     */
    public function getAltImagen()
    {
        return $this->alt_imagen;
    }

    /**
     * @param mixed $alt_imagen
     */
    public function setAltImagen($alt_imagen): void
    {
        $this->alt_imagen = $alt_imagen;
    }

    /**
     * @return mixed
     */
    public function getFecha()
    {
        return $this->fecha;
    }

    /**
     * @param mixed $fecha
     */
    public function setFecha($fecha): void
    {
        $this->fecha = $fecha;
    }

    /**
     * @return mixed
     */
    public function getTitulo()
    {
        return $this->titulo;
    }

    /**
     * @param mixed $titulo
     */
    public function setTitulo($titulo): void
    {
        $this->titulo = $titulo;
    }

    /**
     * @return mixed
     */
    public function getText()
    {
        return $this->text;
    }

    /**
     * @param mixed $text
     */
    public function setText($text): void
    {
        $this->text = $text;
    }

    /**
     * @return mixed
     */
    public function getTag()
    {
        return $this->tag;
    }

    /**
     * @param mixed $tag
     */
    public function setTag($tag): void
    {
        $this->tag = $tag;
    }

    /**
     * Traemos los datos de la base de datos
     * retur Data[]
     */
    public function todoEventosRecomendados(): array
    {
        $db = (new Conexion())->getConexion();
        $query = "SELECT * FROM eventosrecomendados";
        $stmt = $db->prepare($query);
        $stmt->execute();

        $stmt->setFetchMode(PDO::FETCH_CLASS, self::class);

        return $stmt->fetchAll();
    }

    public function traerPorPkEventosRecomendados(int $pk): ?EventosRecomendados
    {
        $db = (new Conexion())->getConexion();
        $query = "SELECT * FROM eventosrecomendados 
                  WHERE id_eventosrecomendados = ?";
        $stmt = $db->prepare($query);

        $stmt->execute([$pk]);
        $stmt->setFetchMode(PDO::FETCH_CLASS, self::class);
        $eventosrecomendado = $stmt->fetch();

        if(!$eventosrecomendado) {
            return null;
        }
        return $eventosrecomendado;
    }

}