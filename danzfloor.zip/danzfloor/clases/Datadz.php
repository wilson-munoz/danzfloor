<?php

class Datadz
{
    protected $id_datadz;
    protected $imagen;
    protected $alt_imagen;
    protected $fecha;
    protected $titulo;
    protected $subtitulo;
    protected $text_intro;
    protected $imagen_detalle;
    protected $img_alt_detalle;
    protected $text_detalle;
    protected $titulo_detalle;

    /**
     * @return mixed
     */
    public function getIdDatadz()
    {
        return $this->id_datadz;
    }

    /**
     * @param mixed $id_datadz
     */
    public function setIdDatadz($id_datadz): void
    {
        $this->id_datadz = $id_datadz;
    }

    /**
     * @return mixed
     */
    public function getImagen()
    {
        return $this->imagen;
    }

    /**
     * @param mixed $imagen
     */
    public function setImagen($imagen): void
    {
        $this->imagen = $imagen;
    }

    /**
     * @return mixed
     */
    public function getAltImagen()
    {
        return $this->alt_imagen;
    }

    /**
     * @param mixed $alt_imagen
     */
    public function setAltImagen($alt_imagen): void
    {
        $this->alt_imagen = $alt_imagen;
    }

    /**
     * @return mixed
     */
    public function getFecha()
    {
        return $this->fecha;
    }

    /**
     * @param mixed $fecha
     */
    public function setFecha($fecha): void
    {
        $this->fecha = $fecha;
    }

    /**
     * @return mixed
     */
    public function getTitulo()
    {
        return $this->titulo;
    }

    /**
     * @param mixed $titulo
     */
    public function setTitulo($titulo): void
    {
        $this->titulo = $titulo;
    }

    /**
     * @return mixed
     */
    public function getSubtitulo()
    {
        return $this->subtitulo;
    }

    /**
     * @param mixed $subtitulo
     */
    public function setSubtitulo($subtitulo): void
    {
        $this->subtitulo = $subtitulo;
    }

    /**
     * @return mixed
     */
    public function getTextIntro()
    {
        return $this->text_intro;
    }

    /**
     * @param mixed $text_intro
     */
    public function setTextIntro($text_intro): void
    {
        $this->text_intro = $text_intro;
    }

    /**
     * @return mixed
     */
    public function getImagenDetalle()
    {
        return $this->imagen_detalle;
    }

    /**
     * @param mixed $imagen_detalle
     */
    public function setImagenDetalle($imagen_detalle): void
    {
        $this->imagen_detalle = $imagen_detalle;
    }

    /**
     * @return mixed
     */
    public function getImgAltDetalle()
    {
        return $this->img_alt_detalle;
    }

    /**
     * @param mixed $img_alt_detalle
     */
    public function setImgAltDetalle($img_alt_detalle): void
    {
        $this->img_alt_detalle = $img_alt_detalle;
    }

    /**
     * @return mixed
     */
    public function getTextDetalle()
    {
        return $this->text_detalle;
    }

    /**
     * @param mixed $text_detalle
     */
    public function setTextDetalle($text_detalle): void
    {
        $this->text_detalle = $text_detalle;
    }

    /**
     * @return mixed
     */
    public function getTituloDetalle()
    {
        return $this->titulo_detalle;
    }

    /**
     * @param mixed $titulo_detalle
     */
    public function setTituloDetalle($titulo_detalle): void
    {
        $this->titulo_detalle = $titulo_detalle;
    }














    /**
     * Busca todas las noticias de la base de datos.
     *
     * @return Datadz[]
     */
    public function todoDatadz(): array
    {
        $db = (new Conexion())->getConexion();
        $query = "SELECT * FROM datadz";
        $stmt = $db->prepare($query);
        $stmt->execute();

        $stmt->setFetchMode(PDO::FETCH_CLASS, self::class);

        // Retornamos el array de objetos Producto.
        return $stmt->fetchAll();
    }

    /**
     * Trae la noticia asociada a la $pk.
     *
     * @param int $pk
     * @return Datadz|null
     */
    public function traerPorPkDatadz(int $pk): ?Datadz
    {
        $db = (new Conexion())->getConexion();
        $query = "SELECT * FROM datadz
              WHERE id_datadz = ?";
        $stmt = $db->prepare($query);

        // Pasamos el valor asociado.
        $stmt->execute([$pk]);
        $stmt->setFetchMode(PDO::FETCH_CLASS, self::class);
        $datad = $stmt->fetch();

        if(!$datad) {
            return null;
        }
        return $datad;
    }


    /**
     * Crea una noticia en la base de datos.
     *
     * @param array $data
     * @throws PDOException
     */
    public function crear(array $data)
    {
        $db = (new Conexion())->getConexion();
        // NO OLVIDAR LOS HOLDERS.
        $query = "INSERT INTO datadz (fk_usuarios, fecha, imagen, alt_imagen, titulo, subtitulo, text_intro, titulo_detalle, imagen_detalle, text_detalle)
                VALUES (
                        :fk_usuarios, 
                        NOW(), 
                        :imagen, 
                        :alt_imagen, 
                        :titulo, :subtitulo, 
                        :text_intro, 
                        :titulo_detalle, 
                        :imagen_detalle, 
                        :text_detalle)";
        $stmt = $db->prepare($query);
        $stmt->execute([
            'fk_usuarios'       => $data['fk_usuarios'],
            'imagen'            => $data['imagen'],
            'alt_imagen'        => $data['alt_imagen'],
            'titulo'            => $data['titulo'],
            'subtitulo'         => $data['subtitulo'],
            'text_intro'        => $data['text_intro'],
            'titulo_detalle'    => $data['titulo_detalle'],
            'imagen_detalle'    => $data['imagen_detalle'],
            'text_detalle'      => $data['text_detalle']
        ]);
    }



//    public function editar(int $pk, array $data)
    public function editar(int $id, array $data)
    {
        $db = (new Conexion())->getConexion();
        $query = "UPDATE datadz
                  SET   fk_usuarios  = :fk_usuarios,
                        imagen       = :imagen,
                        alt_imagen   = :alt_imagen,
                        titulo       = :titulo,
                        subtitulo  = :subtitulo,
                        text_intro = :text_intro,
                        titulo_detalle = :titulo_detalle,
                        text_detalle = :text_detalle,
                        imagen_detalle = :imagen_detalle,
                        img_alt_detalle = :img_alt_detalle
                  WHERE id_datadz = :id_datadz";
        
        $stmt = $db->prepare($query);
        $stmt->execute([
            'id_datadz'         => $id,
            'fk_usuarios'       => $data['fk_usuarios'],
            'imagen'            => $data['imagen'],
            'alt_imagen'        => $data['alt_imagen'],
            'titulo'            => $data['titulo'],
            'subtitulo'         => $data['subtitulo'],
            'text_intro'        => $data['text_intro'],
            'titulo_detalle'    => $data['titulo_detalle'],
            'text_detalle'      => $data['text_detalle'],
            'imagen_detalle'    => $data['imagen_detalle'],
            'img_alt_detalle'   => $data['img_alt_detalle']
        ]);
    }


    /**
     * Elimina el item por su PK de la base de datos.
     *
     * @param int $pk
     */
    public function eliminar(int $pk)
    {
        $db = (new Conexion())->getConexion();
        $query = "DELETE FROM datadz
                  WHERE id_datadz= ?";
        $stmt = $db->prepare($query);
        $stmt->execute([$pk]);
    }





}


