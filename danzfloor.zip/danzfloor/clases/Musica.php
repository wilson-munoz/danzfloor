<?php

class Musicapremieres
{
    protected $id_musicapremieres;
    protected $link;

    /**
     * @return mixed
     */
    public function getIdMusicapremieres()
    {
        return $this->id_musicapremieres;
    }

    /**
     * @return mixed
     */
    public function getLink()
    {
        return $this->link;
    }


    /**
     * Busca toda la musica de la base de datos.
     *
     * @return Musicapremieres[]
     */

    public function todoMusicapremieres(): array
    {
        $db = (new Conexion())->getConexion();
        $query = "SELECT * FROM musicapremieres";
        $stmt = $db->prepare($query);
        $stmt->execute();

        $stmt->setFetchMode(PDO::FETCH_CLASS, self::class);
        return $stmt->fetchAll();
    }

    /**
     * Trae la musica asociada a la pk
     * @param int $pk
     * @return Musicapremieres/null
     */
    public function traerPorPkMusicapremieres(int $pk): ?Musicapremieres
    {
        $db = (new Conexion())->getConexion();
        $query = "SELECT * FROM musicapremieres
              WHERE id_musicapremieres = ?";
        $stmt = $db->prepare($query);

        // Pasamos el valor asociado.
        $stmt->execute([$pk]);
        $stmt->setFetchMode(PDO::FETCH_CLASS, self::class);
        $musicapremieres = $stmt->fetch();

        if(!$musicapremieres) {
            return null;
        }
        return $musicapremieres;
    }


    /**
     * Crea una noticia en la base de datos.
     *
     * @param array $data
     * @throws PDOException
     */
    public function crearpremiere(array $data)
    {
        $db = (new Conexion())->getConexion();
        $query = "INSERT INTO musicapremieres (fk_usuarios,  link)
                VALUES ( :fk_usuarios, :link)";
        $stmt = $db->prepare($query);
        $stmt->execute([
            'fk_usuarios'       => $data['fk_usuarios'],
            'link'       => $data['link']
        ]);
    }


    /**
     * Elimina el item por su PK de la base de datos.
     *
     * @param int $pk
     */
    public function eliminarpremieres(int $pk)
    {
        $db = (new Conexion())->getConexion();
        $query = "DELETE FROM musicapremieres
                  WHERE id_musicapremieres = ?";
        $stmt = $db->prepare($query);
        $stmt->execute([$pk]);
    }



}

















