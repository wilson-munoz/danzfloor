<?php

class Cronicasdz
{
    protected $id_cronicadz;
    protected $imagen;
    protected $alt_imagen;
    protected $fecha;
    protected $titulo;
    protected $subtitulo;
    protected $descripcion;
    protected $tag;

    /**
     * @return mixed
     */
    public function getIdCronicadz()
    {
        return $this->id_cronicadz;
    }

    /**
     * @param mixed $id_cronicadz
     */
    public function setIdCronicadz($id_cronicadz): void
    {
        $this->id_cronicadz = $id_cronicadz;
    }

    /**
     * @return mixed
     */
    public function getImagen()
    {
        return $this->imagen;
    }

    /**
     * @param mixed $imagen
     */
    public function setImagen($imagen): void
    {
        $this->imagen = $imagen;
    }

    /**
     * @return mixed
     */
    public function getAltImagen()
    {
        return $this->alt_imagen;
    }

    /**
     * @param mixed $alt_imagen
     */
    public function setAltImagen($alt_imagen): void
    {
        $this->alt_imagen = $alt_imagen;
    }

    /**
     * @return mixed
     */
    public function getFecha()
    {
        return $this->fecha;
    }

    /**
     * @param mixed $fecha
     */
    public function setFecha($fecha): void
    {
        $this->fecha = $fecha;
    }

    /**
     * @return mixed
     */
    public function getTitulo()
    {
        return $this->titulo;
    }

    /**
     * @param mixed $titulo
     */
    public function setTitulo($titulo): void
    {
        $this->titulo = $titulo;
    }

    /**
     * @return mixed
     */
    public function getSubtitulo()
    {
        return $this->subtitulo;
    }

    /**
     * @param mixed $subtitulo
     */
    public function setSubtitulo($subtitulo): void
    {
        $this->subtitulo = $subtitulo;
    }

    /**
     * @return mixed
     */
    public function getDescripcion()
    {
        return $this->descripcion;
    }

    /**
     * @param mixed $descripcion
     */
    public function setDescripcion($descripcion): void
    {
        $this->descripcion = $descripcion;
    }

    /**
     * @return mixed
     */
    public function getTag()
    {
        return $this->tag;
    }

    /**
     * @param mixed $tag
     */
    public function setTag($tag): void
    {
        $this->tag = $tag;
    }




    /**
     * Traemos los datos de data desde la base
     * @return Cronicasdz[]
     */
    public function todoCronicasdz(): array
    {
        $db = (new Conexion())->getConexion();
        $query = "SELECT * FROM cronicasdz";
        $stmt = $db->prepare($query);
        $stmt->execute();

        $stmt->setFetchMode(PDO::FETCH_CLASS, self::class);

        return $stmt->fetchAll();
    }

    public function traerPorPkCronicasdz(int $pk): ?Cronicasdz
    {
        $db = (new Conexion())->getConexion();
        $query = "SELECT * FROM cronicasdz
                  WHERE id_cronicasdz = ?";
        $stmt = $db->prepare($query);

        $stmt->execute([$pk]);
        $stmt->setFetchMode(PDO::FETCH_CLASS, self::class);
        $cronicasdz = $stmt->fetch();

        if(!$cronicasdz) {
            return null;
        }
        return $cronicasdz;
    }

}