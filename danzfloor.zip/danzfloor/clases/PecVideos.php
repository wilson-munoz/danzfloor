<?php

class PecVideos
{
    protected $id_pecvideos;
    protected $link_videos;

    /**
     * @return mixed
     */
    public function getIdPecVideos()
    {
        return $this->id_pecvideos;
    }

    /**
     * @param mixed $id_pecvideos
     */
    public function setIdPecVideos($id_pecvideos): void
    {
        $this->id_pecvideos = $id_pecvideos;
    }

    /**
     * @return mixed
     */
    public function getLinkVideos()
    {
        return $this->link_videos;
    }

    /**
     * @param mixed $link
     */
    public function setLink($link): void
    {
        $this->link = $link;
    }

    public function todoPecVideos(): array
    {
        $db = (new Conexion())->getConexion();
        $query = "SELECT * FROM pecvideos";
        $stmt = $db->prepare($query);
        $stmt->execute();

        $stmt->setFetchMode(PDO::FETCH_CLASS, self::class);

        return $stmt->fetchAll();

    }

    public function traerPorPkPecVideos(int $pk): ?PecVideos
    {
        $db = (new Conexion())->getConexion();
        $query = "SELECT * FROM pecvideos
                  WHERE id_pecvideos = ?";
        $stmt = $db->prepare($query);

        $stmt->execute([$pk]);
        $stmt->setFetchMode(PDO::FETCH_CLASS, self::class);
        $pecvideos = $stmt->fetchAll();

        if(!$pecvideos) {
            return null;
        }
        return $pecvideos;
    }



    /**
     * Crea una noticia en la base de datos.
     *
     * @param array $data
     * @throws PDOException
     */
    public function crearvideos(array $data)
    {
        $db = (new Conexion())->getConexion();
        $query = "INSERT INTO pecvideos (fk_usuarios,  link_videos)
                VALUES ( :fk_usuarios, :link_videos)";
        $stmt = $db->prepare($query);
        $stmt->execute([
            'fk_usuarios'       => $data['fk_usuarios'],
            'link_videos'       => $data['link_videos']
        ]);
    }


    /**
     * Elimina el item por su PK de la base de datos.
     *
     * @param int $pk
     */
    public function eliminar(int $pk)
    {
        $db = (new Conexion())->getConexion();
        $query = "DELETE FROM pecvideos
                  WHERE id_pecvideos= ?";
        $stmt = $db->prepare($query);
        $stmt->execute([$pk]);
    }

}