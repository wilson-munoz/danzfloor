<?php
require_once __DIR__ . '/bootstrap/init.php';
require_once __DIR__ . '/clases/Conexion.php';
require_once __DIR__ . '/bootstrap/rutas.php';
require_once __DIR__ . '/bootstrap/conexion.php';

require_once __DIR__  . '/clases/Home.php';
require_once __DIR__  . '/clases/EventosRecomendados.php';
require_once __DIR__ . '/clases/Datadz.php';
require_once __DIR__  . '/clases/Musica.php';
require_once __DIR__  . '/clases/MusicaVideos.php';
require_once __DIR__  . '/clases/Pec.php';
require_once __DIR__ . '/clases/PecVideos.php';
require_once __DIR__ . '/clases/PecDescarga.php';
require_once __DIR__  . '/clases/Cronicasdz.php';

$rutas = getRutas();

$vista = $_GET['s'] ?? 'home';

if(!isset($rutas[$vista ])) {
    $vista = '404';
}
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Danzfloor <?= $rutas[$vista]['title']?></title>

<!--    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">-->


    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" integrity="sha512-xh6O/CkQoPOWDdYTDqeRdPCVd1SpvCA9XXcUnZS2FmJNp1coAFzvtCN9BmamE+4aHK8yyUHUSCcJHgXloTyT2A==" crossorigin="anonymous" referrerpolicy="no-referrer" />

    <link rel="stylesheet" href="css/styleslider.css">
    <link rel="stylesheet" href="css/flexslider.css">

    <link rel="stylesheet" href="css/slidetestimony.css">
<!--    <link rel="stylesheet" href="css/slidefooter.css">-->

    <link rel="stylesheet" href="css/marcas.css">

    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <header>
        <div>
           <a href="index.php?s=home"> <h1 id="logo">Danzfloor</h1></a>
            <div>
                <div class="redes-head">
                    <a href=""><i class="fa-brands fa-youtube"></i></a>
                    <a href=""><i class="fa-brands fa-instagram"></i></a>
                    <a href=""><i class="fa-brands fa-discord"></i></a>
                    <a href=""><i class="fa-brands fa-soundcloud"></i></a>
                </div>
                <a href="#" id="menu-toggle" onclick='toggle_menu(); return false;'></a>
            </div>
        </div>

        <nav class="nav">
            <ul>
                <li>
                    <a href="index.php?s=data">
                        <span class="nav-main">Data</span>
                        <img class="icon-nav" src="imgs/icon-nav.png" alt="Icon">
                        <span class="nav-bajada"> Newz, artistas, reseñas, lanzamientos y más.</span>
                        <div class="icon-men"></div>
                    </a>
                </li>
                <li>
                    <a href="index.php?s=pec">
                        <span class="nav-main">#Pec</span>
                        <span>Por una escena consciente.</span>
                    </a>
                </li>
                <li>
                    <a href="index.php?s=musica">
                        <span class="nav-main">Música</span>
                        <span class="nav-bajada">Premieres y podcast.</span>
                    </a>
                </li>
                <li>
                    <a href="https://discord.com/" target="_blank">
                        <span class="nav-main">Foro online</span>
                        <span class="nav-bajada">¡Chatea con la comunidad en discord!</span>
                    </a>
                </li>
                <li><a href="index.php?s=networking">
                        <span class="nav-main">Networking</span>
                        <span class="nav-bajada"> Un encuentro para tejer redes.</span>
                    </a>
                </li>
                <li>
                    <a href="index.php?s=que-es-danzfloor">
                        <span class="nav-main">¿Que es Danzfloor?</span>
                    </a>
                </li>
                <li>
                    <a href="index.php?s=como-podes-involucrarte">
                        <span class="nav-main">¿Como podés involucrarte?</span>
                    </a>
                </li>
            </ul>
        </nav>
    </header>

<?php
require 'vistas/' . $vista . '.php';
?>

<footer class="footer">
    <div id="footer">
        <div class="contact-footer">
            <div class="redes-footer">
                <div>
                    <h2>Redes</h2>
                    <span></span>
                    <span></span>
                </div>
                <ul>
                    <li><a href=""><i class="fa-brands fa-youtube"></i></a></li>
                    <li><a href=""><i class="fa-brands fa-instagram"></i></a></li>
                    <li><a href=""><i class="fa-brands fa-discord"></i></a></li>
                    <li><a href=""><i class="fa-brands fa-soundcloud"></i></a></li>
                </ul>
                <div class="borde__redes-footer">
                    <span></span>
                    <span></span>
                </div>
            </div>
            <div class="email-footer">
                <a href="#">hola@danzfloor.com</a>
                <a href="#">prensa@danzfloor.com</a>
            </div>
            <div>

            </div>
        </div>
        <div id="marcas-footer">
            <div class="footer-marcas">
                <div>
                    <span></span>
                </div>
                <div class="marcas-footer">
                    <span><p>Acompañan este proyecto </p></span>
                    <div class="borde__top-footer">
                        <span></span>
                        <span><p>Acompañan este proyecto</p></span>
                    </div>
                    <div class="slider">

                        <div class="slide-track-1">
                            <div class="slide">
                                <img src="imgs/oficial-parnet.png" alt="">
                            </div>
                            <div class="slide">
                                <img src="imgs/filtros-argentina.png" alt="">
                            </div>

                            <div class="slide">
                                <img src="imgs/flate.png" alt="">
                            </div>
                            <div class="slide">
                                <img src="imgs/cyberwax.png" alt="">
                            </div>
                            <div class="slide">
                                <img src="imgs/oficial-parnet.png" alt="">
                            </div>
                            <div class="slide">
                                <img src="imgs/filtros-argentina.png" alt="">
                            </div>

                            <div class="slide">
                                <img src="imgs/flate.png" alt="">
                            </div>
                            <div class="slide">
                                <img src="imgs/cyberwax.png" alt="">
                            </div>
                            <div class="slide">
                                <img src="imgs/oficial-parnet.png" alt="">
                            </div>
                            <div class="slide">
                                <img src="imgs/filtros-argentina.png" alt="">
                            </div>

                            <div class="slide">
                                <img src="imgs/flate.png" alt="">
                            </div>
                            <div class="slide">
                                <img src="imgs/cyberwax.png" alt="">
                            </div>
                            <div class="slide">
                                <img src="imgs/oficial-parnet.png" alt="">
                            </div>
                            <div class="slide">
                                <img src="imgs/filtros-argentina.png" alt="">
                            </div>

                            <div class="slide">
                                <img src="imgs/flate.png" alt="">
                            </div>
                            <div class="slide">
                                <img src="imgs/cyberwax.png" alt="">
                            </div>
                            <div class="slide">
                                <img src="imgs/oficial-parnet.png" alt="">
                            </div>
                            <div class="slide">
                                <img src="imgs/filtros-argentina.png" alt="">
                            </div>

                            <div class="slide">
                                <img src="imgs/flate.png" alt="">
                            </div>
                            <div class="slide">
                                <img src="imgs/cyberwax.png" alt="">
                            </div>
                            <div class="slide">
                                <img src="imgs/oficial-parnet.png" alt="">
                            </div>
                            <div class="slide">
                                <img src="imgs/filtros-argentina.png" alt="">
                            </div>

                            <div class="slide">
                                <img src="imgs/flate.png" alt="">
                            </div>
                            <div class="slide">
                                <img src="imgs/cyberwax.png" alt="">
                            </div>
                        </div>
                    </div>

                </div>

            </div>

            <div class="border__copy">
                <span></span>
                <span></span>
            </div>
        </div>
        <!--    <div class="border-marcas"></div>-->
        <!--    <div></div>-->
        <div class="footer-copy">
            <p>Danzfloor &copy; 2022</p>
            <p>Politica de privacidad</p>
        </div>
    </div>

</footer>

<script src="js/slidetestimony.js"></script>

<!--MENU HAMBURGUESA-->
    <script>
        function toggle_menu() {
            document.querySelector('body').classList.toggle('menu_abierto')
        }
    </script>
<!--FIN MENU HAMBURGUESA-->

    <!-- js -->
    <script type="text/javascript" src="js/jquery-2.1.4.min.js"></script>

    <!-- Necessary-JavaScript-File-For-Bootstrap -->
    <script type="text/javascript" src="js/bootstrap.js"></script>
    <!-- //js -->

    <!-- Stats-Number-Scroller-Animation-JavaScript -->
    <script src="js/waypoints.min.js"></script>
    <script src="js/counterup.min.js"></script>
    <script>
        jQuery(document).ready(function( $ ) {
            $('.counter').counterUp({
                delay: 100,
                time: 1000
            });
        });
    </script>
    <!-- //Stats-Number-Scroller-Animation-JavaScript -->



    <!-- Banner Responsiveslides -->
    <script src="js/responsiveslides.min.js"></script>
    <script>
        // You can also use "$(window).load(function() {"
        $(function () {
            // Slideshow 4
            $("#slider3").responsiveSlides({
                auto: true,
                pager: true,
                nav: false,
                speed: 500,
                namespace: "callbacks",
                before: function () {
                    $('.events').append("<li>before event fired.</li>");
                },
                after: function () {
                    $('.events').append("<li>after event fired.</li>");
                }
            });

        });
    </script>
    <!-- // Banner Responsiveslides -->


    <!-- FlexSlider-JavaScript -->
    <script defer src="js/jquery.flexslider.js"></script>
    <script type="text/javascript">
        $(function(){
            SyntaxHighlighter.all();
        });
        $(window).load(function(){
            $('.flexslider').flexslider({
                animation: "slide",
                start: function(slider){
                    $('body').removeClass('loading');
                }
            });
        });
    </script>
    <!-- //FlexSlider-JavaScript -->



<!--marcas-->
<script src="js/marcasfooter.js"></script>
<script src="js/slidermarcas.js"></script>
<script>
    try {
        fetch(new Request("https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js", { method: 'HEAD', mode: 'no-cors' })).then(function(response) {
            return true;
        }).catch(function(e) {
            var carbonScript = document.createElement("script");
            carbonScript.src = "//cdn.carbonads.com/carbon.js?serve=CK7DKKQU&placement=wwwjqueryscriptnet";
            carbonScript.id = "_carbonads_js";
            document.getElementById("carbon-block").appendChild(carbonScript);
        });
    } catch (error) {
        console.log(error);
    }
</script>
<!--<script type="text/javascript">-->
<!---->
<!--    var _gaq = _gaq || [];-->
<!--    _gaq.push(['_setAccount', 'UA-36251023-1']);-->
<!--    _gaq.push(['_setDomainName', 'jqueryscript.net']);-->
<!--    _gaq.push(['_trackPageview']);-->
<!---->
<!--    (function() {-->
<!--        var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;-->
<!--        ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';-->
<!--        var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);-->
<!--    })();-->
<!---->
<!--</script>-->


<!--Fotos responsive-->
<script>
    document.createElement("picture");
</script>
<script src="js/picturefill.js" async></script>

</body>
</html>
