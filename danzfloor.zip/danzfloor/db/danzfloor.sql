-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 13-02-2023 a las 03:02:35
-- Versión del servidor: 10.4.24-MariaDB
-- Versión de PHP: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `danzfloor`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cronicasdz`
--

CREATE TABLE `cronicasdz` (
  `id_cronicasdz` int(10) UNSIGNED NOT NULL,
  `fk_usuarios` int(10) UNSIGNED NOT NULL,
  `imagen` varchar(250) NOT NULL,
  `alt_imagen` varchar(250) NOT NULL,
  `fecha` date NOT NULL,
  `titulo` varchar(250) NOT NULL,
  `subtitulo` varchar(250) NOT NULL,
  `descripcion` text NOT NULL,
  `tag` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `datadz`
--

CREATE TABLE `datadz` (
  `id_datadz` int(10) UNSIGNED NOT NULL,
  `fk_usuarios` int(10) UNSIGNED NOT NULL,
  `imagen` varchar(250) NOT NULL,
  `alt_imagen` varchar(250) NOT NULL,
  `fecha` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `titulo` varchar(250) NOT NULL,
  `subtitulo` varchar(250) NOT NULL,
  `text_intro` text NOT NULL,
  `imagen_detalle` varchar(250) NOT NULL,
  `img_alt_detalle` varchar(250) NOT NULL,
  `text_detalle` mediumtext NOT NULL,
  `text_color` varchar(250) NOT NULL,
  `titulo_detalle` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `datadz`
--

INSERT INTO `datadz` (`id_datadz`, `fk_usuarios`, `imagen`, `alt_imagen`, `fecha`, `titulo`, `subtitulo`, `text_intro`, `imagen_detalle`, `img_alt_detalle`, `text_detalle`, `text_color`, `titulo_detalle`) VALUES
(1, 1, 'dos-chicas-cantando.jpg', 'Dos chicas cantando', '2023-01-29 09:22:50', 'Cielo y Tierra', 'la voz como vínculo intuitivo y sanador', 'La pandemia fue muy dura, pero al mismo tiempo permitió a muchas personas explorar nuevos horizontes artísticos. El duo “Cielo y Terra”, fueron creados en cuarentena', 'data-detalle1.jpg', '', '', '', 'Cielo y Terra: la voz como vínculo intuitivo '),
(2, 1, 'chicos-en-escenario.jpg', 'Dos chicos en un escenario', '0000-00-00 00:00:00', 'A/V- “Tríptico”, por Gonzalez+Molina', '', '“Tríptico” es un concierto audiovisual de música y pantallas. “Todo estará plasmado en una misma noche y a lo largo de varias escenas”.', '', '', '', '', ''),
(4, 1, 'chico-hablando-por-telefono.jpg', 'Un Chico hablando por telefono', '0000-00-00 00:00:00', '“Post Mortem”', 'el último disco de Dillom', 'Para esta nueva edición de DZ Urbano analizaremos “Post Mortem”, el último disco de Dillom, editado en diciembre de 2021.', '', '', '', '', ''),
(5, 1, 'chica-meditando.jpg', 'Un chica meditando', '0000-00-00 00:00:00', 'Radar de Mujeres y Disidencias:', 'Ana Roman(USA)', 'Ana Roman es unx artista digital: DJ híbridx y productorx que actualmente experimenta e investiga con la visualización de data musical y la Inteligencia Artificial.', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `eventos`
--

CREATE TABLE `eventos` (
  `id_eventos` int(10) UNSIGNED NOT NULL,
  `fk_usuarios` int(10) UNSIGNED NOT NULL,
  `imagen` varchar(250) NOT NULL,
  `alt_imagen` varchar(45) NOT NULL,
  `fecha` date NOT NULL,
  `titulo` varchar(250) NOT NULL,
  `descripcion` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `eventosrecomendados`
--

CREATE TABLE `eventosrecomendados` (
  `id_eventosrecomendados` int(10) UNSIGNED NOT NULL,
  `fk_usuarios` int(10) UNSIGNED NOT NULL,
  `imagen` varchar(250) NOT NULL,
  `alt_imagen` varchar(240) NOT NULL,
  `fecha` date NOT NULL,
  `titulo` varchar(45) NOT NULL,
  `text` text NOT NULL,
  `tag` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `eventosrecomendados`
--

INSERT INTO `eventosrecomendados` (`id_eventosrecomendados`, `fk_usuarios`, `imagen`, `alt_imagen`, `fecha`, `titulo`, `text`, `tag`) VALUES
(2, 1, 'desglose.jpg', 'Desglose', '0000-00-00', 'Definiendo Live.', 'Este sábado 21.06 se presentará DEFINIENDO LIVE en Niceto (Humboldt)Todo el show va a estar registrado por 6 cámaras de principio a fin.', ''),
(4, 1, 'volao.jpg', 'Volao', '0000-00-00', 'Volao', 'Este sábado 10.06 se presentará VOLAO en El Emergente', ''),
(7, 1, 'paisajes.jpg', 'Paisajes Improvisados', '0000-00-00', 'Paisajes Improvisados', 'primer edición de “Paisajes Improvisados”, una jam de máquinas e instrumentos, divida en 3 bloques de 45min que organiza @hardwaredreams.', ''),
(8, 1, 'danza-nativa.jpg', 'Danza Nativa', '0000-00-00', 'Danza Nativa', 'Este próximo 25 de Junio, tenemos un nuevo showcase en Under Club. Junto al artista Italiano Claudio PRC (012 / Semántica Records) uno de los máximos exponentes del Deep Techno.', '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `musicapremieres`
--

CREATE TABLE `musicapremieres` (
  `id_musicapremieres` int(10) UNSIGNED NOT NULL,
  `fk_usuarios` int(10) UNSIGNED NOT NULL,
  `link` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `musicapremieres`
--

INSERT INTO `musicapremieres` (`id_musicapremieres`, `fk_usuarios`, `link`) VALUES
(1, 1, 'tracks/1205398390'),
(9, 1, 'playlists/1244950003');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `musicavideos`
--

CREATE TABLE `musicavideos` (
  `id_musicavideos` int(10) UNSIGNED NOT NULL,
  `fk_usuarios` int(10) UNSIGNED NOT NULL,
  `link` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `musicavideos`
--

INSERT INTO `musicavideos` (`id_musicavideos`, `fk_usuarios`, `link`) VALUES
(1, 1, 'embed/1NBo2jlfabo'),
(2, 1, 'embed/Wt8NfchQgBk'),
(4, 1, 'embed/1NBo2jlfabo');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `notasdz`
--

CREATE TABLE `notasdz` (
  `id_notasdz` int(10) UNSIGNED NOT NULL,
  `fk_usuarios` int(10) UNSIGNED NOT NULL,
  `imagen` varchar(250) NOT NULL,
  `alt_imagen` varchar(250) NOT NULL,
  `fecha` date NOT NULL,
  `titulo` varchar(250) NOT NULL,
  `subtitulo` varchar(250) NOT NULL,
  `descripcion` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pec`
--

CREATE TABLE `pec` (
  `id_pec` int(10) UNSIGNED NOT NULL,
  `fk_usuarios` int(10) UNSIGNED NOT NULL,
  `imagen` varchar(250) NOT NULL,
  `alt_imagen` varchar(250) NOT NULL,
  `fecha` time NOT NULL,
  `titulo` varchar(250) NOT NULL,
  `subtitulo` varchar(250) NOT NULL,
  `text_intro` text NOT NULL,
  `titulo_detalle` varchar(255) NOT NULL,
  `imagen_detalle` varchar(255) NOT NULL,
  `img_alt_detalle` varchar(255) NOT NULL,
  `text_detalle` mediumtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `pec`
--

INSERT INTO `pec` (`id_pec`, `fk_usuarios`, `imagen`, `alt_imagen`, `fecha`, `titulo`, `subtitulo`, `text_intro`, `titulo_detalle`, `imagen_detalle`, `img_alt_detalle`, `text_detalle`) VALUES
(2, 1, 'concierto.jpg', 'Imagen de un concierto con luces naranjas', '00:00:00', 'La cancelación de espacios', '', 'En palabras más específicas y empíricamente culturales, es una sentencia social que provoca distintas consecuencias, algunas buenas y otras no tanto.', 'Quiero producir eventos ¿por dónde empiezo?', 'img-detalle-pec.jpg', '', 'En esta nota hablaremos sobre los desafíos de producir un evento, algunas ideas y consideraciones, tanto para quienes recién se introducen o tienen ganas de empezar, como para aquellxs que ya tienen experiencia.\r\n\r\nTodx productorx sabe que el éxito de un evento no garantiza el éxito del siguiente, debido a las numerosas variables que hay que considerar. Quizás habías organizado una fecha al aire libre y empezó a llover, o unx de lxs artistas se enfermó y tienes que decidir entre un reemplazo, suspender la fecha o cancelarla. ¡Y eso no es todo! ¡Oh no! Pero cómo todx buenx productorx, mantené la calma: no estás sólx.'),
(6, 1, 'dj-consola.jpg', '', '00:00:00', 'Alisú y su participación en Pleamar', '', 'Se acerca una nueva edición del festival de electrónica experimental Pleamar, esta vez en formato enteramente virtual.', '', '', '', ''),
(7, 1, 'personas-bailando.jpg', '', '00:00:00', 'Quiero producir eventos… ¿por dónde empiezo?', '', 'En esta nota hablaremos sobre los desafíos de producir un evento, algunas ideas y consideraciones, tanto para quienes recién se introducen o tienen ganas de empezar, como para aquellxs que ya tienen experiencia.', '', '', '', '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pecdescarga`
--

CREATE TABLE `pecdescarga` (
  `id_pecdescarga` int(10) UNSIGNED NOT NULL,
  `fk_usuarios` int(10) UNSIGNED NOT NULL,
  `texto` varchar(250) NOT NULL,
  `archivo` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `pecdescarga`
--

INSERT INTO `pecdescarga` (`id_pecdescarga`, `fk_usuarios`, `texto`, `archivo`) VALUES
(1, 1, '', '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pecvideos`
--

CREATE TABLE `pecvideos` (
  `id_pecvideos` int(10) UNSIGNED NOT NULL,
  `fk_usuarios` int(10) UNSIGNED NOT NULL,
  `link_videos` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `pecvideos`
--

INSERT INTO `pecvideos` (`id_pecvideos`, `fk_usuarios`, `link_videos`) VALUES
(1, 1, 'embed/1NBo2jlfabo'),
(8, 1, 'embed/tNqJ5yL2wVE'),
(9, 1, 'embed/lBO3dGVokds');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `roles`
--

CREATE TABLE `roles` (
  `id_roles` tinyint(3) UNSIGNED NOT NULL,
  `nombre` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `roles`
--

INSERT INTO `roles` (`id_roles`, `nombre`) VALUES
(1, 'administrador');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tag`
--

CREATE TABLE `tag` (
  `id_tag` int(10) UNSIGNED NOT NULL,
  `nombre` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id_usuarios` int(10) UNSIGNED NOT NULL,
  `fk_roles` tinyint(3) UNSIGNED NOT NULL,
  `nombre` varchar(250) NOT NULL,
  `email` varchar(250) NOT NULL,
  `password` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id_usuarios`, `fk_roles`, `nombre`, `email`, `password`) VALUES
(1, 1, 'wilson', 'wilson@gmail.com', '$2y$10$/ecdnlWuGMeTbE8xWE3nmealTFWWSmQcU2btywosly9Dv6/b8MeJm');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `cronicasdz`
--
ALTER TABLE `cronicasdz`
  ADD PRIMARY KEY (`id_cronicasdz`),
  ADD UNIQUE KEY `id_cronicadz_UNIQUE` (`id_cronicasdz`),
  ADD KEY `fk_cronicadz_usuarios1_idx` (`fk_usuarios`);

--
-- Indices de la tabla `datadz`
--
ALTER TABLE `datadz`
  ADD PRIMARY KEY (`id_datadz`),
  ADD KEY `fk_data_usuarios1_idx` (`fk_usuarios`);

--
-- Indices de la tabla `eventos`
--
ALTER TABLE `eventos`
  ADD PRIMARY KEY (`id_eventos`),
  ADD UNIQUE KEY `id_eventos_UNIQUE` (`id_eventos`),
  ADD KEY `fk_eventos_usuarios1_idx` (`fk_usuarios`);

--
-- Indices de la tabla `eventosrecomendados`
--
ALTER TABLE `eventosrecomendados`
  ADD PRIMARY KEY (`id_eventosrecomendados`),
  ADD UNIQUE KEY `id_eventosrecomendados_UNIQUE` (`id_eventosrecomendados`),
  ADD KEY `fk_eventosrecomendados_usuarios1_idx` (`fk_usuarios`);

--
-- Indices de la tabla `musicapremieres`
--
ALTER TABLE `musicapremieres`
  ADD PRIMARY KEY (`id_musicapremieres`),
  ADD UNIQUE KEY `id_musica_UNIQUE` (`id_musicapremieres`),
  ADD KEY `fk_musica_usuarios1_idx` (`fk_usuarios`);

--
-- Indices de la tabla `musicavideos`
--
ALTER TABLE `musicavideos`
  ADD PRIMARY KEY (`id_musicavideos`),
  ADD UNIQUE KEY `id_musicavideos_UNIQUE` (`id_musicavideos`),
  ADD KEY `fk_musicavideos_usuarios1_idx` (`fk_usuarios`);

--
-- Indices de la tabla `notasdz`
--
ALTER TABLE `notasdz`
  ADD PRIMARY KEY (`id_notasdz`),
  ADD UNIQUE KEY `id_notasdz_UNIQUE` (`id_notasdz`),
  ADD KEY `fk_notasdz_usuarios1_idx` (`fk_usuarios`);

--
-- Indices de la tabla `pec`
--
ALTER TABLE `pec`
  ADD PRIMARY KEY (`id_pec`),
  ADD UNIQUE KEY `id_pec_UNIQUE` (`id_pec`),
  ADD KEY `fk_pec_usuarios1_idx` (`fk_usuarios`);

--
-- Indices de la tabla `pecdescarga`
--
ALTER TABLE `pecdescarga`
  ADD PRIMARY KEY (`id_pecdescarga`),
  ADD KEY `fk_pecdescarga_usuarios1_idx` (`fk_usuarios`);

--
-- Indices de la tabla `pecvideos`
--
ALTER TABLE `pecvideos`
  ADD PRIMARY KEY (`id_pecvideos`),
  ADD UNIQUE KEY `id_pecvideos_UNIQUE` (`id_pecvideos`),
  ADD KEY `fk_pecvideos_usuarios1_idx` (`fk_usuarios`);

--
-- Indices de la tabla `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id_roles`),
  ADD UNIQUE KEY `id_roles_UNIQUE` (`id_roles`);

--
-- Indices de la tabla `tag`
--
ALTER TABLE `tag`
  ADD PRIMARY KEY (`id_tag`),
  ADD UNIQUE KEY `id_tag_UNIQUE` (`id_tag`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id_usuarios`),
  ADD UNIQUE KEY `id_usuarios_UNIQUE` (`id_usuarios`),
  ADD KEY `fk_usuarios_roles_idx` (`fk_roles`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `cronicasdz`
--
ALTER TABLE `cronicasdz`
  MODIFY `id_cronicasdz` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `datadz`
--
ALTER TABLE `datadz`
  MODIFY `id_datadz` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT de la tabla `eventos`
--
ALTER TABLE `eventos`
  MODIFY `id_eventos` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `eventosrecomendados`
--
ALTER TABLE `eventosrecomendados`
  MODIFY `id_eventosrecomendados` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT de la tabla `musicapremieres`
--
ALTER TABLE `musicapremieres`
  MODIFY `id_musicapremieres` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT de la tabla `musicavideos`
--
ALTER TABLE `musicavideos`
  MODIFY `id_musicavideos` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de la tabla `notasdz`
--
ALTER TABLE `notasdz`
  MODIFY `id_notasdz` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `pec`
--
ALTER TABLE `pec`
  MODIFY `id_pec` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT de la tabla `pecdescarga`
--
ALTER TABLE `pecdescarga`
  MODIFY `id_pecdescarga` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `pecvideos`
--
ALTER TABLE `pecvideos`
  MODIFY `id_pecvideos` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT de la tabla `roles`
--
ALTER TABLE `roles`
  MODIFY `id_roles` tinyint(3) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `tag`
--
ALTER TABLE `tag`
  MODIFY `id_tag` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id_usuarios` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `cronicasdz`
--
ALTER TABLE `cronicasdz`
  ADD CONSTRAINT `fk_cronicadz_usuarios1` FOREIGN KEY (`fk_usuarios`) REFERENCES `usuarios` (`id_usuarios`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `datadz`
--
ALTER TABLE `datadz`
  ADD CONSTRAINT `fk_data_usuarios1` FOREIGN KEY (`fk_usuarios`) REFERENCES `usuarios` (`id_usuarios`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `eventos`
--
ALTER TABLE `eventos`
  ADD CONSTRAINT `fk_eventos_usuarios1` FOREIGN KEY (`fk_usuarios`) REFERENCES `usuarios` (`id_usuarios`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `eventosrecomendados`
--
ALTER TABLE `eventosrecomendados`
  ADD CONSTRAINT `fk_eventosrecomendados_usuarios1` FOREIGN KEY (`fk_usuarios`) REFERENCES `usuarios` (`id_usuarios`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `musicapremieres`
--
ALTER TABLE `musicapremieres`
  ADD CONSTRAINT `fk_musica_usuarios1` FOREIGN KEY (`fk_usuarios`) REFERENCES `usuarios` (`id_usuarios`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `musicavideos`
--
ALTER TABLE `musicavideos`
  ADD CONSTRAINT `fk_musicavideos_usuarios1` FOREIGN KEY (`fk_usuarios`) REFERENCES `usuarios` (`id_usuarios`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `notasdz`
--
ALTER TABLE `notasdz`
  ADD CONSTRAINT `fk_notasdz_usuarios1` FOREIGN KEY (`fk_usuarios`) REFERENCES `usuarios` (`id_usuarios`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `pec`
--
ALTER TABLE `pec`
  ADD CONSTRAINT `fk_pec_usuarios1` FOREIGN KEY (`fk_usuarios`) REFERENCES `usuarios` (`id_usuarios`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `pecdescarga`
--
ALTER TABLE `pecdescarga`
  ADD CONSTRAINT `fk_pecdescarga_usuarios1` FOREIGN KEY (`fk_usuarios`) REFERENCES `usuarios` (`id_usuarios`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `pecvideos`
--
ALTER TABLE `pecvideos`
  ADD CONSTRAINT `fk_pecvideos_usuarios1` FOREIGN KEY (`fk_usuarios`) REFERENCES `usuarios` (`id_usuarios`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD CONSTRAINT `fk_usuarios_roles` FOREIGN KEY (`fk_roles`) REFERENCES `roles` (`id_roles`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
