<?php

require_once __DIR__ . '/../../bootstrap/init.php';
require_once RUTA_RAIZ . '/clases/Conexion.php';
//require_once RUTA_RAIZ . '/clases/Datadz.php';
require_once RUTA_RAIZ . '/clases/Pec.php';
require_once RUTA_RAIZ . '/clases/PecVideos.php';
//require_once RUTA_RAIZ . '/clases/Autenticacion.php';


$id = $_POST['id'];

try {
    $videospec = new PecVideos();
    $videospec->eliminar($id);

    $_SESSION['message_exito'] = "¡Éxito! Libro eliminado con éxito";
    header("Location: ../index.php?s=pec");
    exit;
} catch (Exception $e) {
    $_SESSION['message_error'] = "¡Error! No se pudo eliminar el libro";
    header("Location: ../index.php?s=pec");
}