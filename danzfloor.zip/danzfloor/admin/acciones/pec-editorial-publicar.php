<?php

require_once __DIR__ . '/../../bootstrap/init.php';
require_once RUTA_RAIZ . '/clases/Conexion.php';
require_once RUTA_RAIZ . '/clases/Pec.php';
require_once RUTA_RAIZ . '/clases/ValidaciónPec.php';
//require_once RUTA_RAIZ . '/clases/Autenticacion.php';

$imagen             = $_FILES['imagen'];
$alt_imagen         = $_POST['alt_imagen'];
$titulo             = $_POST['titulo'];
$text_intro         = $_POST['text_intro'];
$titulo_detalle     = $_POST['titulo_detalle'];
$text_detalle       = $_POST['text_detalle'];
$imagen_detalle       = $_FILES['imagen_detalle'];


$validator = new ValidacionPec($_POST);
$validator->ejecutar();

if($validator->hayErrores()) {

    $_SESSION['errores'] = $validator->getErrores();

    $_SESSION['old_data'] = $_POST;
    header("Location: ../index.php?s=pec-editorial-nuevo");
    exit;
}

if(!empty($imagen['tmp_name'])) {
    $imagen_nombre = date('YmdHis_') . $imagen['name'];
    move_uploaded_file($imagen['tmp_name'], RUTA_IMGS. DIRECTORY_SEPARATOR . $imagen_nombre);
} else {
    $imagen_nombre = '';
}


if(!empty($imagen_detalle['tmp_name'])) {
    $img_detalle = date('YmdHis_') . $imagen_detalle['name'];
    move_uploaded_file($imagen_detalle['tmp_name'], RUTA_IMGS. DIRECTORY_SEPARATOR . $img_detalle);
} else {
    $img_detalle = '';
}


try {
    $pec = new Pec();
    $pec->crearpec([
        'fk_usuarios'       => 1,
        'imagen'            => $imagen_nombre,
        'alt_imagen'        => $alt_imagen,
        'titulo'            => $titulo,
        'text_intro'        => $text_intro,
        'titulo_detalle'    => $titulo_detalle,
        'text_detalle'      => $text_detalle,
        'imagen_detalle'    => $img_detalle,
    ]);

    $_SESSION['mensaje_exito'] = "¡Éxito! El editorial fue publicado exitosamente.";
    header('Location: ../index.php?s=pec');
} catch(Exception $e) {
    $_SESSION['mensaje_error'] = "¡Error! Ocurrió un error inesperado.";
    header('Location: ../index.php?s=pec-editorial-nuevo');
}

