<?php
require_once __DIR__ . '/../../bootstrap/init.php';
require_once RUTA_RAIZ . '/clases/Conexion.php';
require_once RUTA_RAIZ . '/clases/ValidacionNoticia.php';

require_once RUTA_RAIZ . '/clases/Datadz.php';
require_once RUTA_RAIZ . '/clases/Pec.php';
require_once RUTA_RAIZ . '/clases/PecVideos.php';

$link_videos = $_POST['link_videos'];

try {
    $pecvideos = new PecVideos();
    $pecvideos->crearvideos([
        'fk_usuarios' => 1,
        'link_videos' => $link_videos,
    ]);
    $_SESSION['mensaje_exito'] = "¡Éxito! El video fue publicado exitosamente.";
    header('Location: ../index.php?s=pec');
} catch (Exception $e) {
    $_SESSION['mensaje_error'] = "¡Error! Ocurrió un error inesperado al publicar el video.";
    header('Location: ../index.php?s=pec-videos-nuevo');
}