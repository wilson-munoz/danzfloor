<?php

require_once __DIR__ . '/../../bootstrap/init.php';
require_once RUTA_RAIZ . '/clases/Conexion.php';
require_once RUTA_RAIZ . '/clases/Datadz.php';
require_once RUTA_RAIZ . '/clases/ValidacionNoticia.php';
//require_once RUTA_RAIZ . '/clases/Autenticacion.php';

$imagen             = $_FILES['imagen'];
$alt_imagen         = $_POST['alt_imagen'];
$titulo             = $_POST['titulo'];
$subtitulo          = $_POST['subtitulo'];
$text_intro         = $_POST['text_intro'];
$titulo_detalle     = $_POST['titulo_detalle'];
$text_detalle       = $_POST['text_detalle'];
$imagen_detalle       = $_FILES['imagen_detalle'];



$validator = new ValidacionNoticia($_POST);
$validator->ejecutar();

if($validator->hayErrores()) {

    $_SESSION['errores'] = $validator->getErrores();

    $_SESSION['old_data'] = $_POST;
    header("Location: ../index.php?s=data-nuevo");
    exit;
}

if(!empty($imagen['tmp_name'])) {
    $imagen_nombre = date('YmdHis_') . $imagen['name'];
    move_uploaded_file($imagen['tmp_name'], RUTA_IMGS. DIRECTORY_SEPARATOR . $imagen_nombre);
} else {
    $imagen_nombre = '';
}


if(!empty($imagen_detalle['tmp_name'])) {
    $img_detalle = date('YmdHis_') . $imagen_detalle['name'];
    move_uploaded_file($imagen_detalle['tmp_name'], RUTA_IMGS. DIRECTORY_SEPARATOR . $img_detalle);
} else {
    $img_detalle = '';
}


try {
    $datadz = new Datadz();
    $datadz->crear([
        'fk_usuarios'       => 1,
        'imagen'            => $imagen_nombre,
        'alt_imagen'        => $alt_imagen,
        'titulo'            => $titulo,
        'subtitulo'         => $subtitulo,
        'text_intro'        => $text_intro,
        'titulo_detalle'    => $titulo_detalle,
        'text_detalle'      => $text_detalle,
        'imagen_detalle'    => $img_detalle,
    ]);

    $_SESSION['mensaje_exito'] = "¡Éxito! La noticia fue publicada exitosamente.";
    header('Location: ../index.php?s=data');
} catch(Exception $e) {
    $_SESSION['mensaje_error'] = "¡Error! Ocurrió un error inesperado.";
    header('Location: ../index.php?s=data-nuevo');
}

