<?php
require_once __DIR__ . '/../../bootstrap/init.php';
require_once RUTA_RAIZ . '/clases/Conexion.php';
require_once RUTA_RAIZ . '/clases/PecDescarga.php';
//require_once RUTA_RAIZ . '/clases/ValidaciónPec.php';

$id = $_POST['id'];
$texto = $_POST['texto'];
$archivo = $_FILES['archivo'];
$archivo_actual = $_POST['archivo_actual'];


die ("Desarrollo en proceso...");

if (!empty($id)) {
    $dataActual = (new PecDescarga())->traerPorPkPecDescarga($id);
}

if(!empty($archivo['tmp_name'])) {
    $archivo_nombre = date('YmdHis_') . $archivo['name'];
    move_uploaded_file($archivo['tmp_name'], RUTA_IMGS . DIRECTORY_SEPARATOR . $archivo_nombre);
} else {

    $archivo_nombre = $dataActual->getArchivo();
}


//try {
    $pecdescarga = new PecDescarga();
    $pecdescarga->editarpecdescarga($id, [
        'fk_usuarios' => 1,
        'texo' => $texto,
        'archivo_actual' => $archivo_actual,
    ]);
    if(!empty($archivo['tmp_name'])) {
        unlink(RUTA_IMGS . DIRECTORY_SEPARATOR . $dataActual->getArchivo());
    }
    $_SESSION['mensaje_exito'] = "Se actualizó con éxito.";
    header('Location: ../index.php?s=pec');
//} catch (Exception $e) {
    $_SESSION['mensaje_error'] = "¡Error! Ocurrió un error al actualizar.";
    header('Location: ../index.php?s=pec-descarga-editar&id=' . $id);
//}