<?php

require_once __DIR__ . '/../../bootstrap/init.php';
require_once RUTA_RAIZ . '/clases/Conexion.php';

require_once RUTA_RAIZ . '/clases/Musica.php';
require_once RUTA_RAIZ . '/clases/MusicaVideos.php';


$id = $_POST['id'];

try {
    $musicavideos = new MusicaVideos();
    $musicavideos->eliminarMusicaVideos($id);

    $_SESSION['message_exito'] = "¡Éxito! Audio eliminado con éxito";
    header("Location: ../index.php?s=musica");
    exit;
} catch (Exception $e) {
    $_SESSION['message_error'] = "¡Error! No se pudo eliminar el audio";
    header("Location: ../index.php?s=musica");
}