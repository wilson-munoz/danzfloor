<?php

require_once __DIR__ . '/../../bootstrap/init.php';
require_once RUTA_RAIZ . '/clases/Conexion.php';
require_once RUTA_RAIZ . '/clases/Pec.php';
//require_once RUTA_RAIZ . '/clases/Autenticacion.php';


$id = $_POST['id'];

try {
    $pec = new Pec();
    $pec->eliminarpec($id);

    $_SESSION['message_exito'] = "¡Éxito! Editorial eliminado";
    header("Location: ../index.php?s=pec");
    exit;
} catch (Exception $e) {
    $_SESSION['message_error'] = "¡Error! No se pudo eliminar el editorial";
    header("Location: ../index.php?s=pec");
}