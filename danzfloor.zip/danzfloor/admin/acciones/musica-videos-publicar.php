<?php
require_once __DIR__ . '/../../bootstrap/init.php';
require_once RUTA_RAIZ . '/clases/Conexion.php';
require_once RUTA_RAIZ . '/clases/ValidacionNoticia.php';

require_once RUTA_RAIZ . '/clases/Musica.php';
require_once RUTA_RAIZ . '/clases/MusicaVideos.php';


$link = $_POST['link'];

try {
    $musicavideos = new MusicaVideos();
    $musicavideos->crearmusicavideos([
        'fk_usuarios' => 1,
        'link' => $link,
    ]);
    $_SESSION['mensaje_exito'] = "¡Éxito! El video fue publicado exitosamente.";
    header('Location: ../index.php?s=musica');
} catch (Exception $e) {
    $_SESSION['mensaje_error'] = "¡Error! Ocurrió un error inesperado al publicar el video.";
    header('Location: ../index.php?s=musica-videos-nuevo');
}