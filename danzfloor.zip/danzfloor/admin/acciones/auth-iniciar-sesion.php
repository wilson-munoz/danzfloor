<?php

require_once __DIR__ . '/../../bootstrap/init.php';
require_once RUTA_RAIZ . '/clases/Conexion.php';
require_once RUTA_RAIZ . '/clases/Usuario.php';

$email      = $_POST['email'];
$password   = $_POST['password'];

$usuario = (new Usuario())->traerPorEmail($email);


if(!$password_verify($password, $usuario->getPassword())) {
    echo "coinciden";
}
echo "no coinciden";

//
//echo "<pre>";
//var_dump($usuario);
//echo "</pre>";