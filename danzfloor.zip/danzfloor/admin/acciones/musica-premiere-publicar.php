<?php
require_once __DIR__ . '/../../bootstrap/init.php';
require_once RUTA_RAIZ . '/clases/Conexion.php';
//require_once RUTA_RAIZ . '/clases/ValidacionNoticia.php';

require_once RUTA_RAIZ . '/clases/Musica.php';

$link = $_POST['link'];

try {
$musicapremieres = new Musicapremieres();
$musicapremieres->crearpremiere([
    'fk_usuarios' => 1,
    'link' => $link,
]);
$_SESSION['mensaje_exito'] = "¡Éxito! El audio fue publicado exitosamente.";
header('Location: ../index.php?s=musica');
} catch (Exception $e) {
$_SESSION['mensaje_error'] = "¡Error! Ocurrió un error inesperado al publicar el audio.";
header('Location: ../index.php?s=musica-premiere-nuevo');
}