<?php
require_once __DIR__ . '/../bootstrap/init.php';
require_once RUTA_RAIZ . '/clases/Conexion.php';
require_once RUTA_RAIZ . '/bootstrap/rutas.php';
//require_once __DIR__ . '/../bootstrap/conexion.php';

require_once RUTA_RAIZ . '/clases/Home.php';
require_once RUTA_RAIZ . '/clases/Datadz.php';
require_once RUTA_RAIZ . '/clases/Pec.php';
require_once RUTA_RAIZ . '/clases/PecVideos.php';
require_once RUTA_RAIZ . '/clases/PecDescarga.php';
require_once RUTA_RAIZ . '/clases/Musica.php';
require_once RUTA_RAIZ . '/clases/MusicaVideos.php';
//require_once RUTA_RAIZ . '/clases/EventosRecomendados.php';
//require_once RUTA_RAIZ . '/clases/Cronicasdz.php';

$rutas = getRutas();

$rutas = getRutasAdmin();

$vista = $_GET['s'] ?? 'login';

if(!isset($rutas[$vista ])) {
    $vista = '404';
}

$mensajeExito = $_SESSION['mensaje_exito'] ?? null;
$mensajeError = $_SESSION['mensaje_error'] ?? null;
unset($_SESSION['mensaje_exito'], $_SESSION['mensaje_error']);
?>

<!doctype html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Danzfloor || <?= $rutas[$vista]['title']?></title>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" integrity="sha512-xh6O/CkQoPOWDdYTDqeRdPCVd1SpvCA9XXcUnZS2FmJNp1coAFzvtCN9BmamE+4aHK8yyUHUSCcJHgXloTyT2A==" crossorigin="anonymous" referrerpolicy="no-referrer" />

    <link rel="stylesheet" href="../css/admin.css">
    <link rel="stylesheet" href="../css/marcas.css">
<!--    <link rel="stylesheet" href="../css/style.css">-->
</head>
<body>
<header>
    <div>
        <a href="../index.php?s=home"> <h1 id="logo">Danzfloor</h1></a>
        <div>
            <a href="#" id="menu-toggle" onclick='toggle_menu(); return false;'></a>
        </div>
    </div>

    <nav class="nav">
        <ul>
            <li>
                <a href="index.php?s=home">
                    <span class="nav-main">Home</span>
                </a>
            </li>
            <li>
                <a href="index.php?s=data">
                    <span class="nav-main">Data</span>
<!--                    <img class="icon-nav" src="imgs/icon-nav.png" alt="Icon">-->
                    <span class="nav-bajada"> Newz, artistas, reseñas, lanzamientos y más.</span>
                    <div class="icon-men"></div>
                </a>
            </li>
            <li>
                <a href="index.php?s=pec">
                    <span class="nav-main">#Pec</span>
                    <span class="nav-bajada">Por una escena consciente.</span>
                </a>
            </li>
            <li>
                <a href="index.php?s=musica">
                    <span class="nav-main">Música</span>
                    <span class="nav-bajada">Premieres y podcast.</span>
                </a>
            </li>
<!--            <li>-->
<!--                <a href="https://discord.com/" target="_blank">-->
<!--                    <span class="nav-main">Foro online</span>-->
<!--                    <span class="nav-bajada">¡Chatea con la comunidad en discord!</span>-->
<!--                </a>-->
<!--            </li>-->
<!--            <li><a href="index.php?s=networking">-->
<!--                    <span class="nav-main">Networking</span>-->
<!--                    <span class="nav-bajada"> Un encuentro para tejer redes.</span>-->
<!--                </a>-->
<!--            </li>-->
<!--            <li>-->
<!--                <a href="index.php?s=que-es-danzfloor">-->
<!--                    <span class="nav-main">¿Que es Danzfloor?</span>-->
<!--                </a>-->
<!--            </li>-->
<!--            <li>-->
<!--                <a href="index.php?s=como-podes-involucrarte">-->
<!--                    <span class="nav-main">¿Como podés involucrarte?</span>-->
<!--                </a>-->
<!--            </li>-->
        </ul>
    </nav>
</header>
<div class="main-admin">
    <?php
    if($mensajeExito !== null):
        ?>
        <div class="msg-success"><?= $mensajeExito;?></div>
    <?php
    endif;
    ?>

    <?php
    if($mensajeError !== null):
        ?>
        <div class="msg-error"><?= $mensajeError;?></div>
    <?php
    endif;
    ?>

    <?php
    require 'vistas/' . $vista . '.php';
    ?>
</div>

<footer class="footer-admin">
    <p>Panel de Administración</p>
</footer>

<!--MENU HAMBURGUESA-->
<script>
    function toggle_menu() {
        document.querySelector('body').classList.toggle('menu_abierto')
    }
</script>
<!--FIN MENU HAMBURGUESA-->

<!--Fotos responsive-->
<script>
    document.createElement("picture");
</script>
<script src="../js/picturefill.js" async></script>

</body>
</html>
