<?php
//$data = new Datadz;
if(isset($_SESSION['errores'])) {
    $errores = $_SESSION['errores'];
    unset($_SESSION['errores']);
} else {
    $errores = [];
}

if(isset($_SESSION['old_data'])) {
    $oldData = $_SESSION['old_data'];
    unset($_SESSION['old_data']);
} else {
    $pec = (new Pec())->traerPorPkPec($_GET['id']);
    $oldData = [
        'id'                    => $pec->getIdPec(),
        'fecha'                 => $pec->getFecha(),
        'imagen_actual'         => $pec->getImagen(),
        'alt_imagen'            => $pec->getAltImagen(),
        'titulo'                => $pec->getTitulo(),
        'text_intro'            => $pec->getTextIntro(),
        'titulo_detalle'        => $pec->getTituloDetalle(),
        'img_actual_detalle'    => $pec->getImagenDetalle(),
        'img_alt_detalle'       => $pec->getImgAltDetalle(),
        'text_detalle'          => $pec->getTextDetalle(),
    ];
}

?>
<main class="main-admin">
    <section class="form-editar">
        <form action="acciones/pec-editorial-editar.php" enctype="multipart/form-data" method="post">
            <input type="hidden" name="id" value="<?= $oldData['id'];?>">
            <input type="hidden" name="imagen_actual" value="<?= $oldData['imagen_actual'];?>">
            <input type="hidden" name="img_actual_detalle" value="<?= $oldData['img_actual_detalle'];?>">
            <div>
                <label for="titulo">Titulo</label>
                <input
                    type="text"
                    name="titulo"
                    id="titulo"
                    aria-describedby="help-titulo <?= isset($errores['titulo']) ? 'error-titulo' : '';?>"
                    value="<?= $oldData['titulo'] ?? '';?>"
                >
                <div class="texto-ayuda" id="help-titulo">Debe tener al menos 5 caracteres.</div>
                <?php
                if(isset($errores['titulo'])):
                    ?>
                    <div class="msg-error" id="error-titulo"><span class="visually-hidden">Error: </span><?= $errores['titulo'];?></div>
                <?php
                endif;
                ?>
            </div>

            <div>
                <label for="text_intro">Texto intro</label>
                <textarea
                    name="text_intro"
                    id="text_intro"
                    <?= isset($errores['text_intro']) ? 'aria-describedby="error-texto"' : '';?>
                ><?= $oldData['text_intro'] ?? '';?></textarea>
                <?php
                if(isset($errores['text_intro'])):
                    ?>
                    <div class="msg-error" id="error-texto"><span class="visually-hidden">Error: </span><?= $errores['text_intro'];?></div>
                <?php
                endif;
                ?>
            </div>

            <div class="imagen">
                <p>Imagen actual:</p>
                <img src="<?= '../imgs/' . $oldData['imagen_actual'];?>" alt="Previsualización">
            </div>
            <div class="imagen">
                <label for="imagen">Imagen (opcional)</label>
                <input type="file" id="imagen" name="imagen" class="form-control" aria-describedby="help-imagen">
                <div class="texto-ayuda" id="help-imagen">Solo elegí una imagen si querés cambiar la actual.</div>
            </div>
            <div class="form-fila">
                <label for="alt_imagen">Imagen Descripción (opcional)</label>
                <input type="text" id="alt_imagen" name="alt_imagen" class="form-control" value="<?= $oldData['alt_imagen'] ?? '';?>">
            </div>
            <div class="separador__noticia_detalle"></div>

            <div>
                <h3>Datos del detalle de la noticia</h3>
            </div>
            <div>
                <label for="titulo_detalle">Titulo del detalle de la noticia</label>
                <input
                    type="text"
                    id="titulo_detalle"
                    name="titulo_detalle"
                    aria-describedby="help-titulo <?= isset($errores['titulo_detalle']) ? 'error_titulo-detalle' : '';?>"
                    value="<?= $oldData['titulo_detalle'] ?? '';?>"
                >
                <div class="texto-ayuda" id="help-titulo">Debe tener al menos 5 caracteres.</div>
                <?php
                if(isset($errores['titulo_detalle'])):
                    ?>
                    <div class="msg-error" id="error_titulo-detalle"><span class="visually-hidden">Error: </span><?= $errores['titulo_detalle'];?></div>
                <?php
                endif;
                ?>
            </div>
            <div>
                <label for="text_detalle">Detalle de la noticia</label>
                <textarea
                    name="text_detalle"
                    id="text_detalle"
                    <?= isset($errores['text_detalle']) ? 'aria-describedby="error-texto"' : '';?>
                ><?= $oldData['text_detalle'] ?? '';?></textarea>
                <?php
                if(isset($errores['text_detalle'])):
                    ?>
                    <div class="msg-error" id="error-texto"><span class="visually-hidden">Error: </span><?= $errores['text_detalle'];?></div>
                <?php
                endif;
                ?>
            </div>

            <div class="imagen">
                <p>Imagen actual:</p>
                <img src="<?= '../imgs/' . $oldData['img_actual_detalle'];?>" alt="Previsualización">
            </div>

            <div class="imagen">
                <label for="imagen">Imagen (opcional)</label>
                <input type="file" id="imagen_detalle" name="imagen_detalle" class="form-control" aria-describedby="help-imagen">
                <div class="texto-ayuda" id="help-imagen">Solo elegí una imagen si querés cambiar la actual.</div>
            </div>
            <div class="form-fila">
                <label for="img_alt_detalle">Imagen Descripción (opcional)</label>
                <input type="text" id="img_alt_detalle" name="img_alt_detalle" class="form-control" value="<?= $oldData['img_alt_detalle'] ?? '';?>">
            </div>

            <button class="button" type="submit">Actualizar noticia</button>
        </form>
    </section>
</main>