<?php
//$data = new Datadz;
if(isset($_SESSION['errores'])) {
    $errores = $_SESSION['errores'];
    unset($_SESSION['errores']);
} else {
    $errores = [];
}

if(isset($_SESSION['old_data'])) {
    $oldData = $_SESSION['old_data'];
    unset($_SESSION['old_data']);
} else {
    $pecdescarga = (new PecDescarga())->traerPorPkPecDescarga($_GET['id']);
    $data = (new Datadz())->traerPorPkDatadz($_GET['id']);
    $oldData = [
        'id'                => $pecdescarga->getIdPecdescarga(),
        'texto'             => $pecdescarga->getTexto(),
//        'archivo'           => $pecdescarga->getArchivo(),
        'archivo_actual'    => $pecdescarga->getArchivo(),
    ];
}
?>

<main class="main-admin">
    <section class="form-editar">
        <form action="acciones/pec-descarga-editar.php" enctype="multipart/form-data" method="post">
            <input type="hidden" name="id" value="<?= $oldData['id'];?>">
            <input type="hidden" name="archivo_actual" value="<?= $oldData['archivo_actual'];?>">
            <div>
                <label for="texto">Texto</label>
                <input
                        type="text"
                        name="texto"
                        id="texto"
                        aria-describedby="help-titulo <?= isset($errores['texto']) ? 'error-titulo' : '';?>"
                        value="<?= $oldData['texto'] ?? '';?>"
                >
                <div class="texto-ayuda" id="help-titulo">Debe tener al menos 5 caracteres.</div>
                <?php
                if(isset($errores['titulo'])):
                    ?>
                    <div class="msg-error" id="error-titulo"><span class="visually-hidden">Error: </span><?= $errores['titulo'];?></div>
                <?php
                endif;
                ?>
            </div>

            <div class="imagen">
                <label for="archivo">Archivo</label>
                <input type="file" id="archivo" name="archivo" class="form-control" aria-describedby="help-imagen">
                <div class="texto-ayuda" id="help-imagen">Solo elegí un archivo si querés cambiar el actual.</div>
            </div>

            <button class="button" type="submit">Actualizar</button>
        </form>
    </section>
</main>