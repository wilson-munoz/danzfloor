<?php

$musicapremieres = (new Musicapremieres)->todoMusicapremieres();

$musicavideos = (new MusicaVideos)->todoMusicaVideos();


?>
<main class="main">
    <section class="musica-audios">
        <h2>Premieres</h2>
        <div class="boton__agregar_nuevo">
            <a href="index.php?s=musica-premiere-nuevo">Agregar un nuevo audio</a>
        </div>
        <div>
            <?php
            foreach ($musicapremieres as $musicapremiere):
                ?>
            <div class="premieres">
                <iframe width="100%" height="" scrolling="no" frameborder="no" allow="autoplay" src="https://w.soundcloud.com/player/?url=https%3A//api.soundcloud.com/<?= $musicapremiere->getLink(); ?>  "></iframe>

                <div class="acciones-musica">
                    <form action="acciones/musica-premiere-eliminar.php" method="POST" class="form-eliminar">
                        <input type="hidden" name="id" value="<?= $musicapremiere->getIdMusicapremieres();?>">
                        <button class="borrar" type="submit"><span>Eliminar</span><i title="eliminar" class="fa-sharp fa-solid fa-trash"></i></button>
                    </form>
                </div>

                <div style="font-size: 10px; color: #cccccc;line-break: anywhere;word-break: normal;overflow: hidden;white-space: nowrap;text-overflow: ellipsis; font-family: Interstate,Lucida Grande,Lucida Sans Unicode,Lucida Sans,Garuda,Verdana,Tahoma,sans-serif;font-weight: 100;"></div>

            </div>
            <?php
            endforeach;
            ?>
        </div>
    </section>
    <section class="musica-videos" >
        <h2>Mirá</h2>
        <div class="boton__agregar_nuevo">
            <a href="index.php?s=musica-videos-nuevo">Agregar un nuevo video</a>
        </div>
        <div id="musica-videos">
            <?php
            foreach ($musicavideos as $musicavideo):
                ?>
                <div class="videos-musica">
                    <iframe src="https://www.youtube.com/<?= $musicavideo->getLink(); ?>"  title="YouTube video player"  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                    <div class="acciones-musica-videos">
                        <form action="acciones/musica-videos-eliminar.php" method="POST" class="form-eliminar-video">
                            <input type="hidden" name="id" value="<?= $musicavideo->getIdMusicavideos();?>">
                            <button class="borrar" type="submit"><span>Eliminar</span><i title="borrar" class="fa-sharp fa-solid fa-trash"></i></button>
                        </form>
                    </div>
                </div>
            <?php
            endforeach;
            ?>
        </div>
    </section>

</main>

<script>
    // Pequeño código para pedir una confirmación para eliminar.
    const formsEliminar = document.querySelectorAll('.form-eliminar');
    for(let i = 0; i < formsEliminar.length; i++) {
        formsEliminar[i].addEventListener('submit', function(ev) {
            const confirmado = confirm("¿Querés eliminar DEFINITIVAMENTE este audio? Esta acción no es reversible.");
            if(!confirmado) {
                // Cancelamos el envío del formulario.
                ev.preventDefault();
            }
        });
    }
</script>

<script>
    // Pequeño código para pedir una confirmación para eliminar.
    const formsEliminarVideo = document.querySelectorAll('.form-eliminar-video');
    for(let i = 0; i < formsEliminarVideo.length; i++) {
        formsEliminarVideo[i].addEventListener('submit', function(ev) {
            const confirmado = confirm("¿Querés eliminar DEFINITIVAMENTE este video? Esta acción no es reversible.");
            if(!confirmado) {
                // Cancelamos el envío del formulario.
                ev.preventDefault();
            }
        });
    }
</script>