<main class="main">
    <section class="main-home">
        <h2 class="titulo-admin">Bienvenidx al panel de administración</h2>

        <p>Desde este panel podrás administrar el contenido principal de la web, podra hacer lo siguiente:</p>
        <ul>
            <li><span>Borrar</span>: Puedes borrar una noticia, un audio o un video, siempre que estes completamente seguro de hacerlo, ya que esta acción es irreversible</li>
            <li><span>Editar</span>: Puedes editar una noticia, como por ejemplo: Editar título y descripción, también puedes cambiar opcionalmente la foto de la noticia</li>
            <li><span>Agregar</span>: Puedes agregar una nueva noticia, un nuevo video y un nuevo audio.</li>
        </ul>
        <p><span>Nota:</span> Cuando termines de hacer cualquier acción en el sitio, asegúrate siempre de cerrar sesión.</p>
    </section>
</main>
