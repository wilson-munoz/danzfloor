<?php
if(isset($_SESSION['errores'])) {
    $errores = $_SESSION['errores'];
    unset($_SESSION['errores']);
} else {
    $errores = [];
}
?>


<main class="main-admin">
    <section class="form-editar">
        <form action="acciones/pec-editorial-publicar.php" enctype="multipart/form-data" method="post">
            <div>
                <label for="titulo">Titulo</label>
                <input
                    type="text"
                    name="titulo"
                    id="titulo"
                    aria-describedby="help-titulo <?= isset($errores['titulo']) ? 'error-titulo' : '';?>"
                >
                <div class="texto-ayuda" id="help-titulo">Debe tener al menos 5 caracteres.</div>
                <?php
                if(isset($errores['titulo'])):
                    ?>
                    <div class="msg-error" id="error-titulo"><span class="visually-hidden">Error: </span><?= $errores['titulo'];?></div>
                <?php
                endif;
                ?>
            </div>

            <div>
                <label for="text_intro">Texto intro</label>
                <textarea
                    id="text_intro"
                    name="text_intro"
                    <?= isset($errores['text_intro']) ? 'aria-describedby="error-texto"' : '';?>
                ></textarea>
                <?php
                if(isset($errores['text_intro'])):
                    ?>
                    <div class="msg-error" id="error-texto"><span class="visually-hidden">Error: </span><?= $errores['text_intro'];?></div>
                <?php
                endif;
                ?>
            </div>

            <div class="imagen">
                <label for="imagen">Imagen</label>
                <input type="file" id="imagen" name="imagen" class="form-control" aria-describedby="help-imagen">
            </div>
            <div class="form-fila">
                <label for="alt_imagen">Descripción de la imagen (opcional)</label>
                <input type="text" id="alt_imagen" name="alt_imagen" class="form-control" value="<?= $oldData['alt_imagen'] ?? '';?>">
            </div>
            <!--            Separador noticia detalle-->
            <div class="separador__noticia_detalle"></div>

            <div>
                <h3>Datos del detalle del editorial</h3>
            </div>
            <div>
                <label for="titulo_detalle">Titulo del detalle del editorial</label>
                <input
                    type="text"
                    id="titulo_detalle"
                    name="titulo_detalle"
                    aria-describedby="help-titulo <?= isset($errores['titulo_detalle']) ? 'error_titulo-detalle' : '';?>"

                >
                <div class="texto-ayuda" id="help-titulo">Debe tener al menos 5 caracteres.</div>
                <?php
                if(isset($errores['titulo_detalle'])):
                    ?>
                    <div class="msg-error" id="error_titulo-detalle"><span class="visually-hidden">Error: </span><?= $errores['titulo_detalle'];?></div>
                <?php
                endif;
                ?>
            </div>
            <div>
                <label for="">Texto del detalle del editorial</label>
                <textarea
                    name="text_detalle"
                    id="text_detalle"
                    <?= isset($errores['text_detalle']) ? 'aria-describedby="error-texto"' : '';?>
                ></textarea>
                <?php
                if(isset($errores['text_detalle'])):
                    ?>
                    <div class="msg-error" id="error-texto"><span class="visually-hidden">Error: </span><?= $errores['text_detalle'];?></div>
                <?php
                endif;
                ?>
            </div>

            <div class="imagen">
                <label for="imagen_detalle">Imagen del detalle del editorial</label>
                <input type="file" id="imagen_detalle" name="imagen_detalle" class="form-control" aria-describedby="help-imagen">
            </div>
            <div class="form-fila">
                <label for="img_alt_imagen">Descripción de la imagen (opcional)</label>
                <input type="text" id="img_alt_imagen" name="img_alt_imagen" class="form-control" value="<?= $oldData['img_alt_imagen'] ?? '';?>">
            </div>

            <button class="button" type="submit">Publicar editorial</button>
        </form>
    </section>
</main>
