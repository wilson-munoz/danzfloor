<?php
$pec = (new Pec)->todoPec();

$pecvideos = (new PecVideos)->todoPecVideos();

$pecdescarga = (new PecDescarga)->todoPecDescarga();
?>

<?php
$mes = array("enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto", "septiembre", "octubre", "noviembre", "diciembre");
date_default_timezone_set('America/Argentina/Buenos_Aires');
?>

<main class="main-admin">
    <h1 class="titulo-admin">#Pec</h1>
    <seccion class="pec-videos">
        <h2 class="subtitulo-admin">Documentales</h2>
        <div class="boton__agregar_nuevo">
            <a href="index.php?s=pec-videos-nuevo">Agregar un nuevo video</a>
        </div>
        <div>
            <?php
            foreach ($pecvideos as $pecvideo):
                ?>
                <div>
                    <iframe src="https://www.youtube.com/<?= $pecvideo->getLinkVideos(); ?>" "title="YouTube video player"  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

                    <div class="acciones-pec-videos">
                        <form action="acciones/pec-videos-eliminar.php" method="POST" class="form-eliminar">
                            <input type="hidden" name="id" value="<?= $pecvideo->getIdPecVideos();?>">
                            <button class="borrar" type="submit"><span>Eliminar</span><i title="eliminar" class="fa-sharp fa-solid fa-trash"></i></button>
                        </form>
                    </div>
                </div>

            <?php
            endforeach;
            ?>
        </div>
    </seccion>

    <section id="pec-noticias">
        <h2 class="subtitulo-admin">Editorial #Pec</h2>
        <div class="boton__agregar_nuevo">
            <a href="index.php?s=pec-editorial-nuevo">Agregar un nuevo editorial</a>
        </div>
        <div class="pec-noticias">
            <?php
            foreach ($pec as $pe):
                ?>
                    <article>
                        <img src="../imgs/<?= $pe->getImagen(); ?>" alt="">
                        <div>
                            <p style="font-size: .8em" class="fecha"> <?php echo "<strong>" . date("d") . " de " . $mes[date("m")-1] . "</strong>" . ", " . date("Y");  ?></p>

                            <h3 class="titulo__article-admin"><?= $pe->getTitulo(); ?></h3>
                            <p><?= $pe->getTextIntro(); ?></p>
                        </div>
                        <div class="acciones-editorial">
                            <a href="index.php?s=pec-editorial-editar&id=<?= $pe->getIdPec();?>"><span>Editar</span> <i title="editar" class="fa-solid fa-pen-to-square"></i></a>
                            <form action="acciones/pec-editorial-eliminar.php" method="POST" class="form-eliminar-pec">
                                <input type="hidden" name="id" value="<?= $pe->getIdPec();?>">
                                <button class="borrar" type="submit"><span>Eliminar</span><i title="borrar" class="fa-sharp fa-solid fa-trash"></i></button>
                            </form>
                        </div>
                    </article>
            <?php
            endforeach;
            ?>
        </div>

        <div class="data-ver-mas">
            <a class="link-button" href="#">Ver Más</a>
        </div>
    </section>
    <section class="pec-descargar">
        <h2>Archivo completo #Pec</h2>
        <?php
        foreach ($pecdescarga as $pecdescargar ):
        ?>
        <div id="pec-descarga">
            <p><?= $pecdescargar->getTexto(); ?></p>
            <div class="acciones-editorial-descarga">
                <a class="link-button" href="../imgs/<?= $pecdescargar->getArchivo(); ?>" download="../imgs/<?= $pecdescargar->getArchivo(); ?>">Descargar</a>
                <a href="index.php?s=pec-descarga-editar&id=<?= $pecdescargar->getIdPecDescarga();?>">Actualizar </a>
            </div>
        </div>
        <?php
        endforeach;
        ?>
    </section>
</main>

<script>
    // Pequeño código para pedir una confirmación para eliminar.
    const formsEliminar = document.querySelectorAll('.form-eliminar');
    for(let i = 0; i < formsEliminar.length; i++) {
        formsEliminar[i].addEventListener('submit', function(ev) {
            const confirmado = confirm("¿Querés eliminar DEFINITIVAMENTE esta video? Esta acción no es reversible.");
            if(!confirmado) {
                // Cancelamos el envío del formulario.
                ev.preventDefault();
            }
        });
    }
</script>

<script>
    // Pequeño código para pedir una confirmación para eliminar.
    const formsEliminarPec = document.querySelectorAll('.form-eliminar-pec');
    for(let i = 0; i < formsEliminarPec.length; i++) {
        formsEliminarPec[i].addEventListener('submit', function(ev) {
            const confirmado = confirm("¿Querés eliminar DEFINITIVAMENTE este editorial? Esta acción no es reversible.");
            if(!confirmado) {
                // Cancelamos el envío del formulario.
                ev.preventDefault();
            }
        });
    }
</script>
