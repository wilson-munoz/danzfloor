<?php

if(isset($_SESSION['errores'])) {
    $errores = $_SESSION['errores'];
    unset($_SESSION['errores']);
} else {
    $errores = [];
}
?>

<main class="main-admin">
    <section class="form-editar form-video-agregar">
        <form action="acciones/musica-videos-publicar.php" method="post">
            <div>
                <label for="video">Link del video || pega el link del video</label>
                <input type="text" name="link" id="video">
            </div>
            <button class="button" type="submit">Publicar video</button>
        </form>
    </section>
</main>

