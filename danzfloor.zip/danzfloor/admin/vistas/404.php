<main class="main-admin">
    <p style="color: #17a2b8">Página no encontrada</p>
</main>