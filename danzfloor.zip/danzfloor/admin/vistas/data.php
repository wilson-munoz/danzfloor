<?php
$datadz = (new Datadz())->todoDatadz();
?>

<?php
$mes = array("enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto", "septiembre", "octubre", "noviembre", "diciembre");
date_default_timezone_set('America/Argentina/Buenos_Aires');
?>
<main class="main">
    <h1 class="titulo-admin">Data</h1>
    <section id="data-article">
        <div class="boton__agregar_nuevo">
            <a href="index.php?s=data-nuevo">Agregar una nueva noticia</a>
        </div>
        <div class="data-article">
            <?php
            foreach ($datadz as $dat):
                ?>
                    <article class="noticia-article">
                        <img src="<?= '../imgs/' . $dat->getImagen(); ?>" alt="<?= $dat->getAltImagen() ?>">
                        <div>
                            <p style="font-size: .8em" class="fecha"> <?php echo "<strong>" . date("d") . " de " . $mes[date("m")-1] . "</strong>" . ", " . date("Y");  ?></p>
                            <h2><?= $dat->getTitulo(); ?>: <span><?= $dat->getSubtitulo(); ?></span></h2>
                            <p><?= $dat->getTextIntro(); ?></p>
                        </div>
                        <div class="acciones-data">
                            <a href="index.php?s=data-editar&id=<?= $dat->getIdDatadz();?>"><span>Editar</span> <i title="editar" class="fa-solid fa-pen-to-square"></i></a>
                            <form action="acciones/data-eliminar.php" method="POST" class="form-eliminar">
                                <input type="hidden" name="id" value="<?= $dat->getIdDatadz();?>">
                                <button class="borrar" type="submit"><span>Eliminar</span><i title="borrar" class="fa-sharp fa-solid fa-trash"></i></button>
                            </form>
                        </div>
                    </article>
            <?php
            endforeach;
            ?>
        </div>
        <div class="data-ver-mas">
            <a class="link-button" href="#">Ver Más</a>
        </div>
    </section>
</main>

<script>
    // Pequeño código para pedir una confirmación para eliminar.
    const formsEliminar = document.querySelectorAll('.form-eliminar');
    for(let i = 0; i < formsEliminar.length; i++) {
        formsEliminar[i].addEventListener('submit', function(ev) {
            const confirmado = confirm("¿Querés eliminar DEFINITIVAMENTE esta noticia? Esta acción no es reversible.");
            if(!confirmado) {
                // Cancelamos el envío del formulario.
                ev.preventDefault();
            }
        });
    }
</script>