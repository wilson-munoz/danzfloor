<main class="main-admin">
    <section class="main-login">
        <h1>Ingresar al panel de administración</h1>
        <p>Ingresá tus credenciales para iniciar sesión e ingresar al panel de administración.</p>

        <form action="acciones/auth-iniciar-sesion.php" method="post">
            <div>
                <label for="email">Email</label>
                <input type="email" name="email" id="email">
            </div>
            <div>
                <label for="password" >Contraseña</label>
                <input type="password" name="password" id="password">
            </div>
            <button type="submit">Ingresar</button>
        </form>
    </section>
</main>